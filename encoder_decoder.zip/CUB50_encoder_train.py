import torch
from Attribute_encoder import Model
from Attribute_encoder import loss_function
from core.CUB50_DataLoader import CUB50DataLoader
# from new_image.CUB_newload import CUBDataLoader
from global_setting import NFS_path
import torch.optim as optim

device = torch.device("cpu")
dataloader = CUB50DataLoader(NFS_path,device)
att = dataloader.att

seenclass = dataloader.seenclasses
seen_att = att[seenclass.long()] # 可见类的属性 150*312
seenclass_prototypes = torch.load('../core/CUB50_all_seenclass_prototypes10_8.pth')
seenclass_prototypes = seenclass_prototypes.to(device)

input_dim = seen_att.shape[1] # the dimension of the attribute semantic vector
hidden_dim = 1024 # the dimension of the hidden layer
output_dim = seenclass_prototypes.shape[1] # the dimension of the visual feature

model = Model(input_dim, hidden_dim, output_dim)
lr = 0.0008 # the step size for gradient descent
# create an instance of the optimizer
optimizer = optim.Adam(model.parameters(), lr=lr)

for j in range(200):
    for i in range(0, 4):  # 迭代样本数次
        print("[{},{}]".format(j+1,i+1))
        model.train()
        optimizer.zero_grad()
        # forward pass the model
        if i==0:
            x_real = seen_att[:(i+1)*10,:]
            z_real = seenclass_prototypes[:(i+1)*10,:]
        else:
            x_real = seen_att[i*10:(i+1)*10,:]
            z_real = seenclass_prototypes[i*10:(i+1)*10,:]
        z_fake, y_fake = model(x_real)  # generated visual feature and decoded attribute semantic vector

        # compute the loss
        loss = loss_function(x_real, z_real, z_fake, y_fake)
        # backward pass the model
        loss.backward()  # compute the gradients
        # update the parameters
        optimizer.step()  # perform gradient descent
        # print the loss
    print(loss)
torch.save(model.state_dict(), "CUB50_attribute_prototypes_model10_8.pth")
