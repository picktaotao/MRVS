import torch
from Attribute_encoder import Model
from core.AWA2DataLoader import AWA2DataLoader
from global_setting import NFS_path
from core.DAZLE_AWA2 import DAZLE
# from core.DAZLE import DAZLE


device = torch.device("cpu")
dataloader = AWA2DataLoader(NFS_path,device)
att = dataloader.att
seenclass = dataloader.seenclasses
seen_att = att[seenclass.long()]
unseenclass = dataloader.unseenclasses
unseen_att = att[unseenclass.long()] # 不可见类的属性 50*312
dim_f = 2048

# define the input dimension, hidden dimension and output dimension
input_dim = unseen_att.shape[1] # the dimension of the attribute semantic vector
hidden_dim = 1850 # the dimension of the hidden layer
output_dim = dim_f # the dimension of the visual feature

# create an instance of the model
model = Model(input_dim, hidden_dim, output_dim)
model.load_state_dict(torch.load('AWA2_attribute_prototypes_model7_1.pth')) ## 原来的
# model.load_state_dict(torch.load("AWA2_attribute_prototypes_model10_7.pth")) ## 改变encoder之后重新训练的
model.eval()
pred_prototypes, attribute_vector = model(unseen_att)
print(pred_prototypes.shape)
torch.save(pred_prototypes,"AWA2_pred_unseen_prototypes10_7.pth")
# torch.save(pred_prototypes,"AWA2_pred_unseen_prototypes_withSS_withgan.pth")


# pred_prototypes = torch.load('AWA2_pred_unseen_prototypes7_1.pth')

test_unseen_feature = dataloader.data['test_unseen']['resnet_features'].to(device)  # 样本特征
test_unseen_label = dataloader.data['test_unseen']['labels']  # 不可见类样本标签
test_unseen_attribute = torch.load("../pred_attribute/AWA2_test_unseen_attribute_1loss.pth")

dim_v = 300  # 属性词向量的维度
init_w2v_att = dataloader.w2v_att
att = dataloader.att

normalize_att = dataloader.normalize_att
lambda_ = 0.1  # 0.1
seenclass = dataloader.seenclasses
unseenclass = dataloader.unseenclasses
uniform_att_1 = False
uniform_att_2 = True
trainable_w2v = True

# 1、加载主模型
main_model = DAZLE(dim_f,dim_v,init_w2v_att,att,normalize_att,
            seenclass,unseenclass,
            lambda_,trainable_w2v,normalize_V=True,normalize_F=True,is_conservative=True,
            uniform_att_1=uniform_att_1,uniform_att_2=uniform_att_2,
            prob_prune=0,desired_mass=1, is_conv=False,
            is_bias=True)
main_model.load_state_dict(torch.load('../core/model_weights.pth'))
# main_model.load_state_dict(torch.load('../core/AWA2_main_model_weights/AWA2_main_model_weights_withweights_10_7_2000b_470e_452.pth'))


main_model.eval() # set the model to evaluation mode
main_model.to(device)
output = main_model(test_unseen_feature,test_unseen_attribute)
image_features = output['F_att_v']

# 计算样本特征与不可见类原型之间的相似性
dot = torch.matmul(image_features, pred_prototypes.t())
# 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
norm_a = torch.norm(image_features, dim=1, keepdim=True)
norm_b = torch.norm(pred_prototypes, dim=1, keepdim=True)
# 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
sample_prototypes_sim = dot / (norm_a * norm_b.t())
max_values, max_indices = torch.topk(sample_prototypes_sim, k=30, dim=0)
print(max_indices.shape)
max_indices_T=max_indices.T
new_pred_prototypes = torch.empty(0)  # 存放一个不可见类所具有全部属性的视觉特征

for i in range(unseenclass.size(0)):
    everyclasssample=image_features[max_indices_T[i]]
    print(everyclasssample.shape)
    everyclasssamplefeaturesum=torch.sum(everyclasssample,dim=0)
    # everyclasssamplefeaturesum=torch.reshape(everyclasssamplefeaturesum,(1,-1))
    # print(everyclasssamplefeaturesum.shape)
    print(pred_prototypes[i].shape)
    newfeaturesum=everyclasssamplefeaturesum+pred_prototypes[i]
    newfeaturesum=torch.reshape(newfeaturesum,(1,-1))
    everynewprototype=newfeaturesum/(1+everyclasssample.shape[0])
    new_pred_prototypes=torch.cat((new_pred_prototypes,everynewprototype),dim=0)
    print(pred_prototypes[i].shape)
print("pred_prototypes.shape: ",pred_prototypes.shape)
torch.save(new_pred_prototypes,"AWA2_pred_unseen_prototypes10_7new.pth")



