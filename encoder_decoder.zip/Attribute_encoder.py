import torch
import torch.nn as nn
import torch.nn.functional as F

# define the encoder network
class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Encoder, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # x: attribute semantic vector of shape (batch_size, input_dim)
        x = F.relu(self.fc1(x)) # hidden layer of shape (batch_size, hidden_dim)
        x = self.fc2(x) # output layer of shape (batch_size, output_dim)
        return x # visual feature of shape (batch_size, output_dim)

# define the decoder network
class Decoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Decoder, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # x: visual feature of shape (batch_size, input_dim)
        x = F.relu(self.fc1(x)) # hidden layer of shape (batch_size, hidden_dim)
        x = self.fc2(x) # output layer of shape (batch_size, output_dim)
        return x # attribute semantic vector of shape (batch_size, output_dim)

# define the model
class Model(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Model, self).__init__()
        self.encoder = Encoder(input_dim, hidden_dim, output_dim)
        self.decoder = Decoder(output_dim, hidden_dim, input_dim)

    def forward(self, x):
        # x: attribute semantic vector of shape (batch_size, input_dim)
        z = self.encoder(x) # visual feature of shape (batch_size, output_dim)
        y = self.decoder(z) # attribute semantic vector of shape (batch_size, input_dim)
        return z,y

# define the loss function


def loss_function(x_real, z_real, z_fake, y_fake):

    mse_loss = nn.MSELoss()
    loss_z = mse_loss(z_real, z_fake) # mean squared error between real and generated visual features
    loss_y = mse_loss(x_real, y_fake) # 属性回归损失
    loss = 0.1*loss_z + loss_y # total loss
    # loss = loss_y  # 只做属性间的损失
    return loss
