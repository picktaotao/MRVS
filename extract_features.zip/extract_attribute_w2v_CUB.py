# -*- coding: utf-8 -*-
"""
Created on Thu Jul  4 13:43:05 2019

@author: badat
"""
import warnings
warnings.filterwarnings("ignore",category=DeprecationWarning)

import os,sys
pwd = os.getcwd()
sys.path.insert(0,pwd)
#%%
print('-'*30)
print(os.getcwd())
print('-'*30)
#%%
import pdb
import pandas as pd
import numpy as np
import gensim.downloader as api
import pickle
import torch
from transformers import BertTokenizer, BertModel
# from sklearn.decomposition import PCA
# 创建一个分词器和一个模型，使用谷歌的bert-base-uncased预训练权重
tokenizer = BertTokenizer.from_pretrained('D:/bert_large')
bert_model = BertModel.from_pretrained('D:/bert_large')
# 输入一个短语列表，得到一个张量列表，每个张量是一个短语的词向量
df = pd.read_csv('../attribute/CUB/new_des.csv')
new_des = df['new_des']
phrase_tensors = []
for s in new_des:
    # print(s)
    # words = s.split(' ')
    # if words[-1] == '':     #remove empty element
    #     words = words[:-1]
    # for w in words:
    input_ids = tokenizer.encode(s, add_special_tokens=True)
    input_tensor = torch.tensor([input_ids])
    with torch.no_grad():
        output_tensor = bert_model(input_tensor)[0]
        # 从输出张量中提取第一个位置的向量，即[CLS]标记的向量，作为短语的词向量
        phrase_tensor = output_tensor[0][0]
        # 将短语的词向量添加到张量列表中
    phrase_tensors.append(phrase_tensor)
# # 打印每个短语的词向量
# for phrase, tensor in zip(new_des, phrase_tensors):
#     print("Phrase:", phrase)
#     print("Tensor:", tensor)
#     print("")
all_w2v = torch.stack(phrase_tensors,dim=0)  # 312*1024
print("all_w2v shape:",all_w2v.shape)
all_w2v = np.array(all_w2v)
with open('../w2v/CUB_attribute_1024dim.pkl','wb') as f:
    pickle.dump(all_w2v,f)
#%%
# print('Loading pretrain w2v model')
# model_name = 'word2vec-google-news-300'#best model
# model = api.load(model_name)
# dim_w2v = 300
# print('Done loading model')
#
# df = pd.read_csv('../attribute/CUB/new_des.csv')
# print(df.head())
# print('Done preprocessing attribute des')
# #%%
# new_des = df['new_des']
# all_w2v = []
# for s in new_des:
#     print(s)
#     words = s.split(' ')
#     if words[-1] == '':     #remove empty element
#         words = words[:-1]
#     w2v = torch.zeros(dim_w2v)
#     for w in words:
#         try:
#             w2v += model[w]
#         except Exception as e:
#             print(e)
#     all_w2v.append(w2v[np.newaxis,:])
# all_w2v=np.concatenate(all_w2v,axis=0)
#
# with open('../w2v/CUB50_attribute.pkl','wb') as f:
#     pickle.dump(all_w2v,f)
