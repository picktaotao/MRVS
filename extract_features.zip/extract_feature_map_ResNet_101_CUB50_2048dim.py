import os,sys

import pandas as pd

pwd = os.getcwd()
sys.path.insert(0,pwd)
#%%
print('-'*30)
print(os.getcwd())
print('-'*30)
#%%
import torch
import torchvision
import torch.nn as nn
from torchvision import datasets, transforms
from torch.utils.data import Dataset, DataLoader
import torchvision.models.resnet as models
from PIL import Image
import h5py
import numpy as np
import scipy.io as sio
import re
import pickle
from global_setting import NFS_path

#%%
#import pdb
#%%
idx_GPU = 0
is_save = True
#%%
print("PyTorch Version: ",torch.__version__)
print("Torchvision Version: ",torchvision.__version__)
#%%


folder1 = "D:/CUB50"
names = os.listdir(folder1) # 子文件夹和子文件的名称
subfolders = [] # 存放每个类的名称
for name in names:
    path = os.path.join(folder1, name)
    path = path.replace("\\", "/")
    if os.path.isdir(path):
        subfolders.append(name)
print(subfolders)

# 定义一个空列表，用于保存路径
path_list = [] # train文件夹中的可见类图像路径
image_label = [] # 每个图像对应的label
# 使用 os.walk 函数遍历文件夹
for root, dirs, files in os.walk(folder1):
    # 遍历当前目录下的文件
    for file in files:
        # 拼接文件的完整路径
        file_path = os.path.join(root, file)
        # 将路径添加到列表中
        file_path = file_path.replace("\\", "/")
        path_list.append(file_path)
        pattern = "|".join([x.replace("+", "\+") for x in subfolders])
        match = re.search(pattern, file_path)
        if match:
            first_match = match.group()
            image_label.append(first_match)
        else:
            print("No match found")
            print(file_path)
print(len(image_label)) # 2936
print(len(path_list)) # 图像的路径

image_unique_label = list(set(image_label))
image_unique_label = sorted(image_unique_label, key=image_label.index)  # 50个字符串的列表
print(image_unique_label)

label_values = np.arange(0,50)
labelname_label_dict = dict(zip(image_unique_label, label_values)) # 50个类别名和对应的label数值
print(labelname_label_dict)

image_label_values = [labelname_label_dict.get(key) for key in image_label] # 将image_label中类名替换成数值，共有2936张图片，这里得到图片的数字label
print(image_label_values)


split_path = os.path.join(NFS_path,'data/xlsa17/data/CUB/att_splits.mat')
matcontent = sio.loadmat(split_path)
allclasses_names = matcontent['allclasses_names']
allclasses_names = pd.DataFrame(allclasses_names)
allclasses_names.index = allclasses_names.index + 1
print(allclasses_names)

class_list = []
for row in allclasses_names.itertuples():
    class_list.append(row._1.item())
all_class = pd.DataFrame(class_list)
all_class.index = all_class.index + 1
print(all_class)
class_index=[]
# 根据image_unique_label查找all_class中对应的索引
for i in image_unique_label:
    # print(all_class.loc[:,0].str.contains(i).any())
    if all_class.loc[:,0].str.contains(i).any():
        c_index = all_class[all_class.loc[:,0].str.contains(i)].dropna(how='all').index
        class_index.append(c_index.item())
print(class_index)
# class_index = all_class[all_class.isin(image_unique_label)].dropna(how='all').index
# print(class_index)

# 从att中提取出我们所挑选的50个类的att
att = matcontent['att']
att = pd.DataFrame(att)
att.index = att.index + 1
att.columns = att.columns + 1  # 将列索引加1
print(att)  # 312*200

our_att = att.loc[:, class_index]
print(our_att)  # 312*50
# 将out_att存为csv文件
# our_att.to_csv('C:/Users/wsco66/Desktop/our_att.csv', index=False, header=False)


save_path = os.path.join(NFS_path,'data/CUB/feature_map_ResNet101_CUB50_2048fea_1024att.hdf5')
attribute_path = '../w2v/CUB_attribute_1024dim.pkl'
model_name = "resnet"

# Batch size for training (change depending on how much memory you have)
batch_size = 32
device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")

model_ref = models.resnet101(pretrained=True)
# for param in model_f.parameters(): # 冻结模型参数，不进行梯度更新
#     param.requires_grad = False
# num_ftrs = model_f.fc.in_features # 获取模型最后一层的输入特征数
# model_f.fc = nn.Linear(num_ftrs, 2048) # 替换模型最后一层为一个全连接层，输出属性的概率
# model_f.eval()

model_f = nn.Sequential(*list(model_ref.children())[:-1])
model_f.to(device)
model_f.eval()

for param in model_f.parameters():
    param.requires_grad = False
#%%
class CustomedDataset(Dataset):
    """Face Landmarks dataset."""

    def __init__(self, image_label , file_paths, transform=None):
        self.image_files = file_paths  # 图片路径名
        self.image_label = image_label  # 图片标签
        self.transform = transform

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        image_file = self.image_files[idx]
        image_label = self.image_label[idx]
        image = Image.open(image_file)
        if image.mode == 'L':
            image=image.convert('RGB')
        if self.transform:
            image = self.transform(image)
        return (image,image_label)

input_size = 224
data_transforms = transforms.Compose([
        transforms.Resize(input_size),
        transforms.CenterCrop(input_size),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

# 划分训练集和验证集，前40类的图片作为训练集，后10类的图片作为测试集
train_list = path_list[:2338]
train_label = image_label_values[:2338]
test_list = path_list[2338:]
test_label = image_label_values[2338:]
dataset = CustomedDataset(image_label_values,path_list,data_transforms)
data = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=False,num_workers=0) # 不打乱，顺序提取图像特征

# 提取图像特征
all_features = []
for i_batch, batch in enumerate(data):
    print(i_batch)
    imgs = batch[0].to(device)
    features = model_f(imgs)
    features = torch.flatten(features, start_dim=1)

    print(features.shape)
    all_features.append(features.cpu().numpy())
all_features = np.concatenate(all_features,axis=0)
image_labels = image_label_values
attributes = our_att.T # 变为50*312
with open(attribute_path,'rb') as f:
    w2v_att = pickle.load(f)
assert w2v_att.shape == (312,1024)
print('save w2v_att')

if is_save:
    f = h5py.File(save_path, "w")
    f.create_dataset('feature_map', data=all_features,compression="gzip")
    f.create_dataset('labels', data=image_labels,compression="gzip")
    f.create_dataset('att', data=attributes,compression="gzip")
    f.create_dataset('w2v_att', data=w2v_att,compression="gzip")
    f.close()

