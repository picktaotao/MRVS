import torch
from core.AWA2DataLoader import AWA2DataLoader
from global_setting import NFS_path
from core.DAZLE_AWA2 import DAZLE
# from core.DAZLE import DAZLE

import torchvision
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import scipy.io as sio
from PIL import Image
import numpy as np
import os,sys
pwd = os.getcwd() # 获取当前工作目录的路径
sys.path.insert(0,pwd) # 将当前工作目录添加到sys.path列表的最前面，首先在该目录中搜索
from torchvision import transforms
import torch.nn.functional as F


idx_GPU = 0
# device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")
torch.backends.cudnn.benchmark = True

dataloader = AWA2DataLoader(NFS_path,device)
dataset = 'AWA2'
img_dir = os.path.join(NFS_path,'data/{}/'.format(dataset))
file_paths = os.path.join(NFS_path,'data/xlsa17/data/{}/res101.mat'.format(dataset))
split_path = os.path.join(NFS_path,'data/xlsa17/data/{}/att_splits.mat'.format(dataset))



dim_f = 2048  # 特征维度
dim_v = 300  # 属性词向量的维度
init_w2v_att = dataloader.w2v_att
att = dataloader.att

normalize_att = dataloader.normalize_att
lambda_ = 0.1  # 0.1
seenclass = dataloader.seenclasses
unseenclass = dataloader.unseenclasses
uniform_att_1 = False
uniform_att_2 = True
trainable_w2v = True

# 1、加载主模型
model = DAZLE(dim_f,dim_v,init_w2v_att,att,normalize_att,
            seenclass,unseenclass,
            lambda_,trainable_w2v,normalize_V=True,normalize_F=True,is_conservative=True,
            uniform_att_1=uniform_att_1,uniform_att_2=uniform_att_2,
            prob_prune=0,desired_mass=1, is_conv=False,
            is_bias=True)
model.load_state_dict(torch.load('model_weights.pth'))
# model.load_state_dict(torch.load('AWA2_main_model_weights/AWA2_main_model_weights_withweights_10_7_2000b_470e_452.pth'))


model.eval() # set the model to evaluation mode
model.to(device)

# # 2、加载属性模型
# attribute_model = torchvision.models.resnet101(pretrained=True) # 加载预训练的resnet18模型
# for param in attribute_model.parameters(): # 冻结模型参数，不进行梯度更新
#     param.requires_grad = False
# num_ftrs = attribute_model.fc.in_features # 获取模型最后一层的输入特征数
# attribute_model.fc = nn.Linear(num_ftrs, att.shape[1]) # 替换模型最后一层为一个全连接层，输出属性的概率
# attribute_model.load_state_dict(torch.load('attribute_model_weights.pth'))
# attribute_model.eval()
# attribute_model.to(device)

# 3、加载可见类和不可见类原型
seenclass_prototypes = torch.load('all_seenclass_prototypes.pth')
seenclass_prototypes = seenclass_prototypes.to(device)
# unseenclass_prototypes = torch.load('all_unseenclass_prototypes_withSS_withgan.pth')
# unseenclass_prototypes = unseenclass_prototypes.to(device)
unseenclass_prototypes = torch.load('../Encoder_Decoder/AWA2_pred_unseen_prototypes10_7new.pth')

print("-"*30)
print("unseen_class_prediction\n")
test_batch_size = 2000
test_niters = dataloader.ntest//test_batch_size + 1
test_unseenclass = dataloader.unseenclasses # 不可见类标签
test_seenclass = dataloader.seenclasses # 测试集中可见类标签
test_unseen_feature = dataloader.data['test_unseen']['resnet_features'].to(device)  # 样本特征
test_unseen_label = dataloader.data['test_unseen']['labels']  # 不可见类样本标签
test_seen_label = dataloader.data['test_seen']['labels']  # 测试时可见类样本标签

test_unseen_attribute = torch.load("../pred_attribute/AWA2_test_unseen_attribute_1loss.pth")


# 获取不可见类的图片特征，接着输入model
# 计算不可见类样本与不可见类原型之间的相似性
print("-"*30)
print("unseen class prediction")
unseen_SP_pred = torch.empty(0).to(device)  # 用于保存不可见类样本所对应的类原型的label
start_index = 0
for j in range(0,test_niters):
    print("第{}次迭代".format(j))
    batch_feature, batch_label, batch_att, end_index = dataloader.next_batch1(test_unseen_attribute,test_batch_size,start_index) # 重写next_batch
    start_index = end_index
    print("start_index:",start_index)
    out_package = model(batch_feature,batch_att) # 前向传播batch_feature
    in_package = out_package
    in_package['batch_label'] = batch_label
    samples_features = out_package['F_att_v'] # 图片特征

    dot = torch.matmul(samples_features, unseenclass_prototypes.t())
    # 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
    norm_a = torch.norm(samples_features, dim=1, keepdim=True)
    norm_b = torch.norm(unseenclass_prototypes, dim=1, keepdim=True)
    # 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
    sample_prototypes_sim = dot / (norm_a * norm_b.t())
    max_values, max_indices = torch.max(sample_prototypes_sim, dim=1)
    pred_labels = test_unseenclass[max_indices]
    print("pred_labels:\n",pred_labels)
    unseen_SP_pred = torch.cat((unseen_SP_pred, pred_labels), dim=0).int() # 预测的label
print("unseen_SP_pred:\n", unseen_SP_pred)
print("-"*30)
print("unseen_SP_pred unique:\n",torch.unique(unseen_SP_pred))
print("unseen_SP_pred shape:", unseen_SP_pred.shape)
count = test_unseen_label.eq(unseen_SP_pred)
equal_count = count.sum()
total_count = test_unseen_label.shape[0]
diff_count = total_count - equal_count
true_rate = equal_count/ total_count
false_rate = diff_count/total_count
print("不可见类正确率：",true_rate)
print("不可见类错误率：",false_rate)

# print("-"*30)
# print("seen class prediction")
# test_niters = dataloader.ntest_seen//test_batch_size + 1
# seen_SP_pred = torch.empty(0).to(device)  # 用于保存测试集中可见类样本所对应的类原型的label
# start_index = 0
# test_seen_attribute = torch.load("../pred_attribute/AWA2_test_seen_attribute_1loss.pth")
#
# for j in range(0,test_niters):
#     print("第{}次迭代".format(j))
#     batch_feature, batch_label, end_index,batch_att = dataloader.next_batch3(test_batch_size,start_index,test_seen_attribute) # 重写next_batch
#     # batch_class_att = att[batch_label.long()]
#     # batch_class_att[batch_class_att < 0] = 0
#     # batch_class_att[batch_class_att > 0] = 1
#     start_index = end_index
#     print("start_index:",start_index)
#     out_package = model(batch_feature,batch_att) # 前向传播batch_feature
#     in_package = out_package
#     in_package['batch_label'] = batch_label
#     samples_features = out_package['F_att_v'] # 图片特征
#
#     dot = torch.matmul(samples_features, seenclass_prototypes.t())
#     # 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
#     norm_a = torch.norm(samples_features, dim=1, keepdim=True)
#     norm_b = torch.norm(seenclass_prototypes, dim=1, keepdim=True)
#     # 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
#     sample_prototypes_sim = dot / (norm_a * norm_b.t())
#     max_values, max_indices = torch.max(sample_prototypes_sim, dim=1)
#     pred_labels = test_seenclass[max_indices]
#     print("pred_labels:\n",pred_labels)
#     seen_SP_pred = torch.cat((seen_SP_pred, pred_labels), dim=0).int() # 预测的label
# print("seen_SP_pred:\n", seen_SP_pred)
# print("-"*30)
# print("seen_SP_pred unique:\n",torch.unique(seen_SP_pred))
# print("seen_SP_pred shape:", seen_SP_pred.shape)
# count = test_seen_label.eq(seen_SP_pred)
# equal_count = count.sum()
# total_count = test_seen_label.shape[0]
# diff_count = total_count - equal_count
# true_rate = equal_count/ total_count
# false_rate = diff_count/total_count
# print("可见类正确率：",true_rate)
# print("可见类错误率：",false_rate)

# 广义零样本学习
print("不可见类在所有类上的预测")
test_niters = dataloader.ntest//test_batch_size + 1

all_prototypes=torch.cat((seenclass_prototypes,unseenclass_prototypes),dim=0)
unseen_SP_pred = torch.empty(0).to(device)  # 用于保存不可见类样本所对应的类原型的label
start_index = 0
for j in range(0,test_niters):
    print("第{}次迭代".format(j))
    batch_feature, batch_label, batch_att, end_index = dataloader.next_batch1(test_unseen_attribute,test_batch_size,start_index) # 重写next_batch
    start_index = end_index
    print("start_index:",start_index)
    out_package = model(batch_feature,batch_att) # 前向传播batch_feature
    in_package = out_package
    # in_package['batch_label'] = batch_label
    samples_features = out_package['F_att_v'] # 图片特征

    dot = torch.matmul(samples_features, all_prototypes.t())
    # 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
    norm_a = torch.norm(samples_features, dim=1, keepdim=True)
    norm_b = torch.norm(all_prototypes, dim=1, keepdim=True)
    # 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
    sample_prototypes_sim = dot / (norm_a * norm_b.t())
    max_values, max_indices = torch.max(sample_prototypes_sim, dim=1)
    pred_labels =torch.zeros_like(max_indices)
    # pred_labels = torch.empty(0).to(device)
    for i in range(max_indices.shape[0]):
        if max_indices[i]<seenclass.size(0):
            pred_labels[i]=seenclass[max_indices[i]]
        else:
            unseenindex=max_indices[i]-seenclass.size(0)
            pred_labels[i]=unseenclass[unseenindex]
    # pred_labels = test_unseenclass[max_indices]
    print("pred_labels:\n",pred_labels)
    print("true label\n",batch_label)
    unseen_SP_pred = torch.cat((unseen_SP_pred, pred_labels), dim=0).int() # 预测的label
print("unseen_SP_pred:\n", unseen_SP_pred)
print("-"*30)
print("unseen_SP_pred unique:\n",torch.unique(unseen_SP_pred))
print("unseen_SP_pred shape:", unseen_SP_pred.shape)
count = test_unseen_label.eq(unseen_SP_pred)
equal_count = count.sum()
total_count = test_unseen_label.shape[0]
diff_count = total_count - equal_count
true_rate = equal_count/ total_count
false_rate = diff_count/total_count
print("广义不可见类正确率：",true_rate)
print("广义不可见类错误率：",false_rate)

print("*"*40)
print("可见类在所有类上的预测")

test_niters = dataloader.ntest_seen//test_batch_size + 1
seen_SP_pred = torch.empty(0).to(device)  # 用于保存测试集中可见类样本所对应的类原型的label
start_index = 0
test_seen_attribute = torch.load("../pred_attribute/AWA2_test_seen_attribute_1loss.pth")

for j in range(0,test_niters):
    print("第{}次迭代".format(j))
    batch_feature, batch_label, end_index,batch_att = dataloader.next_batch3(test_batch_size,start_index,test_seen_attribute) # 重写next_batch
    # batch_class_att = att[batch_label.long()]
    # batch_class_att[batch_class_att < 0] = 0
    # batch_class_att[batch_class_att > 0] = 1
    start_index = end_index
    print("start_index:",start_index)
    out_package = model(batch_feature,batch_att) # 前向传播batch_feature
    in_package = out_package
    in_package['batch_label'] = batch_label
    samples_features = out_package['F_att_v'] # 图片特征

    dot = torch.matmul(samples_features, all_prototypes.t())
    # 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
    norm_a = torch.norm(samples_features, dim=1, keepdim=True)
    norm_b = torch.norm(all_prototypes, dim=1, keepdim=True)
    # 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
    sample_prototypes_sim = dot / (norm_a * norm_b.t())
    max_values, max_indices = torch.max(sample_prototypes_sim, dim=1)
    pred_labels = torch.zeros_like(max_indices)
    # pred_labels = torch.empty(0).to(device)
    for i in range(max_indices.shape[0]):
        if max_indices[i] < seenclass.size(0):
            pred_labels[i] = seenclass[max_indices[i]]
        else:
            unseenindex = max_indices[i] - seenclass.size(0)
            pred_labels[i] = unseenclass[unseenindex]
    print("pred_labels:\n",pred_labels)
    seen_SP_pred = torch.cat((seen_SP_pred, pred_labels), dim=0).int() # 预测的label
print("seen_SP_pred:\n", seen_SP_pred)
print("-"*30)
print("seen_SP_pred unique:\n",torch.unique(seen_SP_pred))
print("seen_SP_pred shape:", seen_SP_pred.shape)
count = test_seen_label.eq(seen_SP_pred)
equal_count = count.sum()
total_count = test_seen_label.shape[0]
diff_count = total_count - equal_count
true_rate = equal_count/ total_count
false_rate = diff_count/total_count
print("广义可见类正确率：",true_rate)
print("广义可见类错误率：",false_rate)



