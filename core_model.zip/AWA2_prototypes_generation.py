import torch
from core.DAZLE_AWA2 import DAZLE
# from core.DAZLE import DAZLE
from global_setting import NFS_path
from core.AWA2DataLoader import AWA2DataLoader
import time
import numpy as np


idx_GPU = 0
# device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")
torch.backends.cudnn.benchmark = True


dataloader = AWA2DataLoader(NFS_path,device)
# test_dataloader = AWA2_test_DataLoader(NFS_path, device)

batch_size = 50
niters = dataloader.ntrain//batch_size  # 23527//50 = 470
# niters=50
dim_f = 2048  # 特征维度
dim_v = 300  # 属性词向量的维度
init_w2v_att = dataloader.w2v_att
att = dataloader.att
normalize_att = dataloader.normalize_att
lambda_ = 0.1  # 0.1
seenclass = dataloader.seenclasses
print("可见类unique标签:\n",seenclass)
unseenclass = dataloader.unseenclasses
uniform_att_1 = False
uniform_att_2 = True
trainable_w2v = True

model = DAZLE(dim_f,dim_v,init_w2v_att,att,normalize_att,
            seenclass,unseenclass,
            lambda_,trainable_w2v,normalize_V=True,normalize_F=True,is_conservative=True,
            uniform_att_1=uniform_att_1,uniform_att_2=uniform_att_2,
            prob_prune=0,desired_mass=1, is_conv=False,
            is_bias=True)
model.load_state_dict(torch.load('model_weights.pth')) # 之前的
# model.load_state_dict(torch.load('AWA2_main_model_weights/AWA2_main_model_weights_withweights_10_7_2000b_470e_452.pth'))

model.eval() # set the model to evaluation mode
model.to(device)

print("*"*30)
print("seenclass prototypes generation")
print("generating prototypes")
allbatch_seenclass_prototypes = torch.empty(0).to(device)
for i in range(0, niters):
    print("第{}次循环".format(i))
    batch_label, batch_feature, batch_att, batch_class_att = dataloader.next_batch(batch_size)

    samples_seenclass_att = dataloader.att[batch_label].to(device)
    samples_seenclass_att[samples_seenclass_att<=0] = 0
    samples_seenclass_att[samples_seenclass_att>0] = 1

    # 与seenclass对应的原型
    outpackage = model(batch_feature,samples_seenclass_att)
    inpackage = outpackage
    inpackage['batch_label'] = batch_label
    batch_prototypes = model.get_seenclass_prototype(inpackage) # 40个类原型
    batch_prototypes.to(device)
    if i == 0:
        allbatch_seenclass_prototypes = batch_prototypes
    else:
        allbatch_seenclass_prototypes += batch_prototypes
all_seenclass_prototypes = allbatch_seenclass_prototypes/niters
print("all_seenclass_prototypes shape:", all_seenclass_prototypes.shape)
torch.save(all_seenclass_prototypes, "all_seenclass_prototypes10_7.pth")


# print("*"*30)
# print("unseenclass prototypes generation")
# print("generating prototypes")
# unseen_data = torch.load("../GAN/unseen_samples_with_gan.pth")
# allbatch_unseenclass_prototypes = torch.empty(0).to(device)
# startindex=0
# for i in range(0, 500):
#     print("第{}次循环".format(i))
#     unseen_feature,unseen_label, unseen_class_att,startindex = dataloader.next_batch_unseen_gan(unseen_data,startindex,500,1)
#     print(unseen_label)
#     samples_unseenclass_att = dataloader.att[unseen_label.long()].to(device)
#     samples_unseenclass_att[samples_unseenclass_att<=0] = 0
#     samples_unseenclass_att[samples_unseenclass_att>0] = 1
#
#     # 与seenclass对应的原型
#     outpackage = model(unseen_feature,samples_unseenclass_att)
#     inpackage = outpackage
#     inpackage['batch_label'] = unseen_label
#     batch_prototypes = model.get_seenclass_prototype(inpackage) # 40个类原型
#     batch_prototypes.to(device)
#     if i == 0:
#         allbatch_unseenclass_prototypes = batch_prototypes
#     else:
#         allbatch_unseenclass_prototypes += batch_prototypes
# allbatch_unseenclass_prototypes = allbatch_unseenclass_prototypes/niters
# print("all_unseenclass_prototypes shape:", allbatch_unseenclass_prototypes.shape)
# # torch.save(all_seenclass_prototypes, "all_seenclass_prototypes_withSS.pth")
# torch.save(allbatch_unseenclass_prototypes, "all_unseenclass_prototypes_withSS_withgan.pth")


# seenclass_prototypes = torch.load('all_seenclass_prototypes.pth')
# seenclass_prototypes = seenclass_prototypes.to(device)
#
# total_class_att_features = torch.empty(0).to(device)

# for i in range(0, niters):
#     print("第{}次循环".format(i))
#     batch_label, batch_feature, batch_att, batch_class_att = dataloader.next_batch(batch_size)  # 采样
#     outpackage = model(batch_feature, batch_class_att)  # 得到图像特征，传下去
#     inpackage = outpackage
#     inpackage['batch_label'] = batch_label
#     batch_class_att_features = model.get_seenclass_att_feature(inpackage)  # 调用函数，得到类属性特征 40*85*2048
#     if i == 0:
#         total_class_att_features = torch.cat((total_class_att_features,batch_class_att_features),dim = 0)
#     else:
#         total_class_att_features = total_class_att_features+batch_class_att_features
# average_class_att_features = total_class_att_features/niters  # 对每个批次的类属性特征求平均，得到最终的类属性特征
# unseen_prototypes = model.get_unseenclass_prototypes2(dataloader.att, seenclass_prototypes) # 计算不可见类视觉原型
# unseen_prototypes = model.get_unseenclass_prototypes1(dataloader.att, average_class_att_features,model.W_3) # 计算不可见类视觉原型
# print("unseen_prototypes shape:",unseen_prototypes.shape)
# torch.save(unseen_prototypes, "all_unseenclass_prototypes.pth")




