import os,sys
import torch
import torch.optim as optim
import torch.nn as nn
import pandas as pd
from core.DAZLE_CUB_score import DAZLE
from core.CUB50_DataLoader import CUB50DataLoader
from global_setting import NFS_path
import importlib
from core.sample_encoder import Encoder,loss_function
import numpy as np
print('-'*30)
print(os.getcwd())
print('-'*30)

device = torch.device("cpu")
torch.backends.cudnn.benchmark = True

dataloader = CUB50DataLoader(NFS_path,device,is_balance=True)
def get_lr(optimizer):
    lr = []
    for param_group in optimizer.param_groups:
        lr.append(param_group['lr'])
    return lr

seed = 214#215#
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
np.random.seed(seed)

batch_size = 2000 # 每个类有40个样本
nepoches = 80
niters = 40#dataloader.ntrain * nepoches//batch_size  # 2338*80//2000 = 92
# print("ntrain总样本数:",dataloader.ntrain) # 7057
dim_f = 2048
dim_v = 300
init_w2v_att = dataloader.w2v_att
att = dataloader.att
print(att)
trainable_w2v = False
lambda_ = 0.1
bias = 0
prob_prune = 0
uniform_att_1 = False
uniform_att_2 = False

seenclass = dataloader.seenclasses
unseenclass = dataloader.unseenclasses
desired_mass = 1
report_interval = 5#niters//nepoches # 70//20 = 3

model = DAZLE(dim_f,dim_v,init_w2v_att,att,None,
            seenclass,unseenclass,
            lambda_,
            trainable_w2v,normalize_V=False,normalize_F=True,is_conservative=True,
            uniform_att_1=uniform_att_1,uniform_att_2=uniform_att_2,
            prob_prune=prob_prune,desired_mass=desired_mass, is_conv=False,
            is_bias=True)
model.to(device)

setup = {'pmp':{'init_lambda':0.1,'final_lambda':0.1,'phase':0.8},
         'desired_mass':{'init_lambda':-1,'final_lambda':-1,'phase':0.8}}
print(setup)

params_to_update = []
params_names = []
for name,param in model.named_parameters():
    if param.requires_grad == True:
        params_to_update.append(param)
        params_names.append(name)
        print("\t",name)

lr = 0.0001
weight_decay = 0.0001#0.000#0.#
momentum = 0.9#0.#

lr_seperator = 1
lr_factor = 1
print('default lr {} {}x lr {}'.format(params_names[:lr_seperator],lr_factor,params_names[lr_seperator:]))
optimizer = optim.RMSprop(params_to_update,lr=lr,weight_decay=weight_decay, momentum=momentum)

print('-'*30)
print('learing rate {}'.format(lr))
print('trainable V {}'.format(trainable_w2v))
print('lambda_ {}'.format(lambda_))
print('optimized seen only')
print('optimizer: RMSProp with momentum = {} and weight_decay = {}'.format(momentum,weight_decay))
print('-'*30)

for i in range(0, niters):  # 迭代样本数次
    model.train()
    # encoder.train()
    optimizer.zero_grad()

    batch_label, batch_feature, batch_att,batch_class_att = dataloader.next_batch(batch_size)
    # print("batch_label:\n",batch_label)
    # print("batch_class_att:\n",batch_class_att) # 40个label
    out_package = model(batch_feature,batch_class_att) # 前向传播batch_feature

    in_package = out_package
    in_package['batch_label'] = batch_label
    in_package['batch_class_att'] = batch_class_att

    # feat_encoder = encoder(out_package['F_att_v'])

    # loss_1 = loss_function(out_package['F_att_v'],feat_encoder)

    # in_package['F_att_v'] = feat_encoder

    out_package = model.compute_total_loss(in_package)
    # loss, loss_PS,loss_PP= out_package['loss'], out_package['loss_PS'],out_package['loss_PP']
    loss,  loss_PS = out_package['loss'],  out_package['loss_PS']


    # loss = loss_1 + loss_2
    loss.backward()
    optimizer.step()
    # if i % report_interval == 0:
    print('-' * 30)
    stats_package = {'iter': i, 'loss': loss.item(), 'loss_PS': loss_PS.item()}
    print(stats_package)
    # if (i+1) % report_interval == 0 or i==0:
    torch.save(model.state_dict(), './CUB50_main_model_weights/CUB50_main_model_weights_withoutPP_10_8_'+str(batch_size)+'b_'+str(niters)+'e_'+str(i+1)+'.pth') # save the model's state_dict to a file
