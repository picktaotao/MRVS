# -*- coding: utf-8 -*-
"""
Created on Sat Jul 20 21:23:18 2019

@author: badat
"""

import os,sys
#import scipy.io as sio
import torch
import numpy as np
import h5py
import time
import pickle
from sklearn import preprocessing
from global_setting import NFS_path
#%%
import scipy.io as sio
import pandas as pd
#%%
import pdb
#%%
dataset = 'AWA2'
img_dir = os.path.join(NFS_path,'data/{}/'.format(dataset))
mat_path = os.path.join(NFS_path,'data/xlsa17/data/{}/res101.mat'.format(dataset))
attr_path = '../attribute/{}/new_des.csv'.format(dataset) # ./attribute/AWA2/new_des.csv


class AWA2DataLoader():
    def __init__(self, data_path, device, is_scale = False,is_balance =True):

        print(data_path)
        sys.path.append(data_path)

        self.data_path = data_path
        self.device = device
        self.dataset = 'AWA2'

        print('$'*30)
        print(self.dataset)
        print('$'*30)
        self.datadir = self.data_path + 'data/{}/'.format(self.dataset) # ../data/AWA2/
        self.index_in_epoch = 0
        self.epochs_completed = 0
        self.is_scale = is_scale
        self.is_balance = is_balance
        if self.is_balance:
            print('Balance dataloader')
        self.read_matdataset()
        self.get_idx_classes()
        # self.read_att()
        # self.read_w2v()
        
    # def augment_img_path(self,mat_path=mat_path,img_dir=img_dir):
    #     self.matcontent = sio.loadmat(mat_path)
    #     self.image_files = np.squeeze(self.matcontent['image_files'])
    #
    #     def convert_path(image_files,img_dir):
    #         new_image_files = []
    #         for idx in range(len(image_files)):
    #             image_file = image_files[idx][0]
    #             image_file = os.path.join(img_dir,'/'.join(image_file.split('/')[5:]))
    #             new_image_files.append(image_file)
    #         return np.array(new_image_files)
    #
    #     self.image_files = convert_path(self.image_files,img_dir)
    #
    #     path= self.datadir + 'feature_map_ResNet_101_{}.hdf5'.format(self.dataset)
    #     hf = h5py.File(path, 'r')
    #
    #     trainval_loc = np.array(hf.get('trainval_loc'))
    #     test_seen_loc = np.array(hf.get('test_seen_loc'))
    #     test_unseen_loc = np.array(hf.get('test_unseen_loc'))
    #
    #     self.data['train_seen']['img_path'] = self.image_files[trainval_loc]
    #     self.data['test_seen']['img_path'] = self.image_files[test_seen_loc]
    #     self.data['test_unseen']['img_path'] = self.image_files[test_unseen_loc]
    #
    #     self.attr_name = pd.read_csv(attr_path)['new_des'] # 若干属性
        
        
    # def next_batch_img(self, batch_size,class_id,is_trainset = False):
    #     features = None
    #     labels = None
    #     img_files = None
    #     if class_id in self.seenclasses:
    #         if is_trainset:
    #             features = self.data['train_seen']['resnet_features']
    #             labels = self.data['train_seen']['labels']
    #             img_files = self.data['train_seen']['img_path']
    #         else:
    #             features = self.data['test_seen']['resnet_features']
    #             labels = self.data['test_seen']['labels']
    #             img_files = self.data['test_seen']['img_path']
    #     elif class_id in self.unseenclasses:
    #         features = self.data['test_unseen']['resnet_features']
    #         labels = self.data['test_unseen']['labels']
    #         img_files = self.data['test_unseen']['img_path']
    #     else:
    #         raise Exception("Cannot find this class {}".format(class_id))
    #
    #     #note that img_files is numpy type !!!!!
    #
    #     idx_c = torch.squeeze(torch.nonzero(labels == class_id))
    #
    #     features = features[idx_c]
    #     labels = labels[idx_c]
    #     img_files = img_files[idx_c.cpu().numpy()]
    #
    #     batch_label = labels[:batch_size].to(self.device)
    #     batch_feature = features[:batch_size].to(self.device)
    #     batch_files = img_files[:batch_size]
    #     batch_att = self.att[batch_label].to(self.device)
    #
    #     return batch_label, batch_feature,batch_files, batch_att

    def next_batch(self, batch_size):  # batch_size = 50
        if self.is_balance:
            idx = []
            n_samples_class = max(batch_size //self.ntrain_class,1) # 确保每个类别在一个批次中都有至少一个样本
            # 从ntrain_class中选择批次大小数量的类别数，返回类别索引
            sampled_idx_c = np.random.choice(np.arange(self.ntrain_class),min(self.ntrain_class,batch_size),replace=False).tolist()
            for i_c in sampled_idx_c:
                idxs = self.idxs_list[i_c] # 从idxs_list中的第i_c个数组中取出样本索引
                idx.append(np.random.choice(idxs,n_samples_class)) # 从样本索引列表中选择一个批次的样本
            idx = np.concatenate(idx)
            idx = torch.from_numpy(idx)
        else:
            idx = torch.randperm(self.ntrain)[0:batch_size]
    
        batch_feature = self.data['train_seen']['resnet_features'][idx].to(self.device)
        batch_label = self.data['train_seen']['labels'][idx].to(self.device)
        batch_att = self.att[batch_label].to(self.device)
        batch_class_att=batch_att
        batch_class_att[batch_class_att<=0]=0
        batch_class_att[batch_class_att>0]=1

        return batch_label, batch_feature, batch_att, batch_class_att

    def next_batch1(self, test_att, test_batch_size, start_index):  # test_batch_size = 2000
        if start_index < self.ntest:
            end_index = min(start_index + test_batch_size, self.ntest)
            batch_feature = self.data['test_unseen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['test_unseen']['labels'][start_index:end_index].to(self.device)
            batch_att = test_att[start_index:end_index].to(self.device)
        return batch_feature, batch_label, batch_att, end_index

    def next_batch2(self, test_batch_size, start_index):
        if start_index < self.ntest_seen:
            end_index = min(start_index + test_batch_size, self.ntest_seen)
            batch_feature = self.data['test_seen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['test_seen']['labels'][start_index:end_index].to(self.device)
        return batch_feature, batch_label, end_index

    def next_batch3(self, test_batch_size, start_index,pred_att):
        if start_index < self.ntest_seen:
            end_index = min(start_index + test_batch_size, self.ntest_seen)
            batch_feature = self.data['test_seen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['test_seen']['labels'][start_index:end_index].to(self.device)
            att=pred_att[start_index:end_index]
        return batch_feature, batch_label, end_index,att



    def next_batch_unseen_gan(self,unseen_data, startindex, num_samples,everyclassbatchnum,ifseen=True):
        features = [item[0] for item in unseen_data]
        # print(features.shape)
        features = torch.stack(features, dim=0)
        features = features.squeeze(1)
        # print(features.shape)
        att = [item[1] for item in unseen_data]
        att = torch.stack(att, dim=0)
        labels = [item[2] for item in unseen_data]
        labels = torch.stack(labels, dim=0)
        if startindex + everyclassbatchnum > num_samples:
            startindex = 0
        batch_features = torch.empty(0)
        batch_labels = torch.empty(0)
        batch_att = torch.empty(0)
        if ifseen:
            classnum = self.seenclasses.size(0)
        else:
            classnum=self.unseenclasses.size(0)

        for i in range(classnum):
            batch_features = torch.cat((batch_features, features[i * num_samples + startindex:i * num_samples + startindex + everyclassbatchnum]),dim=0)
            # batch_label=torch.reshape(labels[i * num_samples + startindex:i * num_samples + startindex + everyclassbatchnum], (1, -1))
            batch_labels = torch.cat((batch_labels, labels[i * num_samples + startindex:i * num_samples + startindex + everyclassbatchnum]),dim=0)
            batch_att = torch.cat((batch_att, att[i * num_samples + startindex:i * num_samples + startindex + everyclassbatchnum]), dim=0)

        batch_class_att=batch_att
        batch_class_att[batch_class_att<=0]=0
        batch_class_att[batch_class_att>0]=1
        startindex = startindex + everyclassbatchnum

        return batch_features, batch_labels, batch_class_att, startindex

    def get_idx_classes(self): # 得到可见类的类别
        n_classes = self.seenclasses.size(0)
        self.idxs_list = []
        train_label = self.data['train_seen']['labels']
        for i in range(n_classes):
            idx_c = torch.nonzero(train_label == self.seenclasses[i].cpu()).cpu().numpy() # 获取非零元素的索引
            idx_c = np.squeeze(idx_c)
            self.idxs_list.append(idx_c)
        return self.idxs_list

    def get_idx_unseen(self):
        n_classes = self.unseenclasses.size(0)
        self.idxs_list = []
        train_label = self.data['train_seen']['labels']

    def read_att(self):
        path = self.datadir + 'feature_map_ResNet_101_{}.hdf5'.format(self.dataset)
        print('_____')
        print(path)
        tic = time.clock()
        hf = h5py.File(path, 'r')
        print('Expert Attr')
        att = np.array(hf.get('att'))
        class_att = np.array(hf.get('att'))
        class_att[class_att<0]=0
        class_att[class_att>0]=1
        print("threshold at zero attribute with negative value")
        att[att < 0] = 0
        self.class_att = torch.from_numpy(class_att).float().cpu()
        self.att = torch.from_numpy(att).float().cpu()



    def read_w2v(self):
        path = self.datadir + 'feature_map_ResNet_101_{}.hdf5'.format(self.dataset)
        print('_____')
        print(path)
        tic = time.clock()
        hf = h5py.File(path, 'r')
        w2v_att = np.array(hf.get('w2v_att'))
        self.w2v_att = torch.from_numpy(w2v_att).float().to(self.device)

    def read_matdataset(self):
        # ../data/AWA2/feature_map_ResNet_101_AWA2.hdf5
        path= self.datadir + 'feature_map_ResNet_101_{}.hdf5'.format(self.dataset)
        print('_____')
        print(path)
        tic = time.clock()
        hf = h5py.File(path, 'r')
        features = np.array(hf.get('feature_map'))
        labels = np.array(hf.get('labels'))

        labels_order,idx = np.unique(labels,return_index=True)
        labels_order = labels_order[np.argsort(idx)] # 返回原有顺序的label
        self.labels_order = labels_order # 传出去

        trainval_loc = np.array(hf.get('trainval_loc'))
        test_seen_loc = np.array(hf.get('test_seen_loc'))
        test_unseen_loc = np.array(hf.get('test_unseen_loc'))
        # test_seen_img_files = np.array(hf.get('test_seen_img_files'))
        # test_unseen_img_files = np.array(hf.get('test_unseen_img_files'))
        # test_seen_files =[]
        # for s in test_seen_img_files:
        #     s = os.path.join(self.datadir, '/'.join(s.split('/')[5:]))
        #     test_seen_files.append(s)
        # test_unseen_files = []
        # for s in test_unseen_img_files:
        #     s = os.path.join(self.datadir, '/'.join(s.split('/')[5:]))
        #     test_unseen_files.append(s)
        # self.test_seen_files = torch.tensor(test_seen_files)
        # self.test_unseen_files = torch.tensor(test_unseen_files)

        print('Expert Attr')
        att = np.array(hf.get('att'))

        print("threshold at zero attribute with negative value")
        att[att<0]=0

        self.att = torch.from_numpy(att).float().to(self.device)

        original_att = np.array(hf.get('original_att'))
        self.original_att = torch.from_numpy(original_att).float().to(self.device)

        w2v_att = np.array(hf.get('w2v_att'))
        self.w2v_att = torch.from_numpy(w2v_att).float().to(self.device)

        self.normalize_att = self.original_att/100
        
        print('Finish loading data in ',time.clock()-tic)
        
        train_feature = features[trainval_loc]
        test_seen_feature = features[test_seen_loc]
        test_unseen_feature = features[test_unseen_loc]
        if self.is_scale: # is_scale = False，不执行
            scaler = preprocessing.MinMaxScaler()
            train_feature = scaler.fit_transform(train_feature)
            test_seen_feature = scaler.fit_transform(test_seen_feature)
            test_unseen_feature = scaler.fit_transform(test_unseen_feature)

        train_feature = torch.from_numpy(train_feature).float() #.to(self.device)
        test_seen_feature = torch.from_numpy(test_seen_feature) #.float().to(self.device)
        test_unseen_feature = torch.from_numpy(test_unseen_feature) #.float().to(self.device)

        train_label = torch.from_numpy(labels[trainval_loc]).long() #.to(self.device)
        test_unseen_label = torch.from_numpy(labels[test_unseen_loc]) #.long().to(self.device)
        test_seen_label = torch.from_numpy(labels[test_seen_loc]) #.long().to(self.device)

        self.seenclasses = torch.from_numpy(np.unique(train_label.cpu().numpy())).to(self.device)
        self.unseenclasses = torch.from_numpy(np.unique(test_unseen_label.cpu().numpy())).to(self.device)
        self.ntrain = train_feature.size()[0]
        self.ntrain_class = self.seenclasses.size(0)
        self.ntest = test_unseen_feature.size()[0]  # 测试不可见类样本数量、
        self.ntest_seen = test_seen_feature.size()[0]  # 测试可见类样本数量
        self.ntest_class = self.unseenclasses.size(0)
        self.train_class = self.seenclasses.clone()
        self.allclasses = torch.arange(0, self.ntrain_class+self.ntest_class).long()

#        self.train_mapped_label = map_label(train_label, self.seenclasses)

        self.data = {}
        self.data['train_seen'] = {}
        self.data['train_seen']['resnet_features'] = train_feature
        self.data['train_seen']['labels']= train_label


        self.data['train_unseen'] = {}
        self.data['train_unseen']['resnet_features'] = None
        self.data['train_unseen']['labels'] = None

        self.data['test_seen'] = {}
        self.data['test_seen']['resnet_features'] = test_seen_feature
        self.data['test_seen']['labels'] = test_seen_label

        self.data['test_unseen'] = {}
        self.data['test_unseen']['resnet_features'] = test_unseen_feature
        self.data['test_unseen']['labels'] = test_unseen_label
