# -*- coding: utf-8 -*-  
"""  
Created on Thu Jul  4 17:39:45 2019  
  
@author: badat  
"""  
  
import torch  
import torch.nn as nn  
import torch.nn.functional as F  
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
#%%  
import pdb  
#%%  
  
class DAZLE(nn.Module):  
    #####  
    # einstein sum notation  
    # b: Batch size \ f: dim feature \ v: dim w2v \ r: number of region \ k: number of classes  
    # i: number of attribute \ h : hidden attention dim  
    #####  
    def __init__(self,dim_f,dim_v,  
                 init_w2v_att,att,normalize_att,  
                 seenclass,unseenclass, 
                 lambda_,  
                 trainable_w2v=False, normalize_V = False, normalize_F = False, is_conservative = False,
                 prob_prune=0,desired_mass=-1,uniform_att_1=False,uniform_att_2=True, is_conv=False,
                 is_bias=False,bias = 1,non_linear_act=False,
                 loss_type='CE',non_linear_emb = False,
                 is_sigmoid=False):
        super(DAZLE, self).__init__()  
        self.dim_f = dim_f  # 视觉特征的维度
        self.dim_v = dim_v  # 属性词向量的维度
        self.dim_att = att.shape[1]  # 属性数量
        self.nclass = att.shape[0]  # 类别数量
        self.hidden = self.dim_att//2
        self.init_w2v_att = init_w2v_att
        self.non_linear_act = non_linear_act # 非线性激活函数
        self.loss_type = loss_type
        if is_conv:
            r_dim = dim_f//2
            self.conv1 = nn.Conv2d(dim_f, r_dim, 2) #[2x2] kernel with same input and output dims
            print('***Reduce dim {} -> {}***'.format(self.dim_f,r_dim))
            self.dim_f = r_dim
            self.conv1_bn = nn.BatchNorm2d(self.dim_f)
            
            
        if init_w2v_att is None:  
            self.V = nn.Parameter(nn.init.normal_(torch.empty(self.dim_att,self.dim_v)),requires_grad = True)  # 属性维度 * 属性数量
        else:
            self.init_w2v_att = F.normalize(init_w2v_att.clone())
            self.V = nn.Parameter(self.init_w2v_att.clone(),requires_grad = trainable_w2v)  
        
        self.att = nn.Parameter(F.normalize(att.clone()),requires_grad = False)
        
        self.W_1 = nn.Parameter(nn.init.normal_(torch.empty(self.dim_v,self.dim_f)),requires_grad = True) #nn.utils.weight_norm(nn.Linear(self.dim_v,self.dim_f,bias=False))#
        self.W_2 = nn.Parameter(nn.init.normal_(torch.empty(self.dim_v,self.dim_f)),requires_grad = True) #nn.utils.weight_norm(nn.Linear(self.dim_v,self.dim_f,bias=False))#
        # self.W_2 = nn.Parameter(nn.init.xavier_uniform_(torch.empty(self.dim_v,self.dim_f)),requires_grad=True)
        ## second layer attenion conditioned on image features
        self.W_3 = nn.Parameter(nn.init.normal_(torch.empty(self.dim_v,self.dim_f)),requires_grad = True)
        
        ''' Compute the similarity between classes  '''
        self.P = torch.mm(self.att,torch.transpose(self.att,1,0))  # att和其转置相乘，得到类别数*类别数的矩阵
        assert self.P.size(1)==self.P.size(0) and self.P.size(0)==self.nclass  # 验证上步是否正确
        self.weight_ce = nn.Parameter(torch.eye(self.nclass).float(),requires_grad = False)#nn.Parameter(torch.tensor(weight_ce).float(),requires_grad = False)  

        self.normalize_V = normalize_V  
        self.normalize_F = normalize_F   
        self.is_conservative = is_conservative  
        self.is_conv = is_conv
        self.is_bias = is_bias
        
        self.seenclass = seenclass  
        self.unseenclass = unseenclass  
        self.normalize_att = normalize_att   
        
        if is_bias:
            self.bias = nn.Parameter(torch.tensor(bias),requires_grad = False)
            mask_bias = np.ones((1,self.nclass))
            mask_bias[:,self.seenclass.cpu().numpy()] *= -1 # 指定索引位置*-1
            self.mask_bias = nn.Parameter(torch.tensor(mask_bias).float(),requires_grad = False)
        
        if desired_mass == -1:  # 不可见类在所有类别中所占的比例，这个目标质量值可以用于定义损失函数、模型训练过程中的权重调整或注意力分配等
            self.desired_mass = self.unseenclass.size(0)/self.nclass#nn.Parameter(torch.tensor(self.unseenclass.size(0)/self.nclass),requires_grad = False)#nn.Parameter(torch.tensor(0.1),requires_grad = False)#  
        else:  
            self.desired_mass = desired_mass#nn.Parameter(torch.tensor(desired_mass),requires_grad = False)#nn.Parameter(torch.tensor(self.unseenclass.size(0)/self.nclass),requires_grad = False)#  
        self.prob_prune = nn.Parameter(torch.tensor(prob_prune),requires_grad = False)
         
        self.lambda_ = lambda_
        self.loss_att_func = nn.BCEWithLogitsLoss()
        self.log_softmax_func = nn.LogSoftmax(dim=1)  
        self.uniform_att_1 = uniform_att_1
        self.uniform_att_2 = uniform_att_2
        
        self.non_linear_emb = non_linear_emb
        
        
        print('-'*30)  
        print('Configuration')  
        
        print('loss_type {}'.format(loss_type))
        
        if self.is_conv:
            print('Learn CONV layer correct')
        
        if self.normalize_V:  
            print('normalize V')  
        else:  
            print('no constraint V')  
              
        if self.normalize_F:  
            print('normalize F')  
        else:  
            print('no constraint F')  
              
        if self.is_conservative:  
            print('training to exclude unseen class [seen upperbound]')  
        ##  属性词向量
        if init_w2v_att is None:
            print('Learning word2vec from scratch with dim {}'.format(self.V.size()))  # V是w2v的clone
        else:  
            print('Init word2vec')  
        
        if self.non_linear_act:
            print('Non-linear relu model')
        else:
            print('Linear model')
        
        print('loss_att {}'.format(self.loss_att_func))  
        print('Bilinear attention module')  
        print('*'*30)  
        print('Measure w2v deviation')
        if self.uniform_att_1:
            print('WARNING: UNIFORM ATTENTION LEVEL 1')
        if self.uniform_att_2:
            print('WARNING: UNIFORM ATTENTION LEVEL 2')
        print('Compute Pruning loss {}'.format(self.prob_prune))  
        if self.is_bias:
            print('Add one smoothing')
        print('Second layer attenion conditioned on image features')
        print('-'*30)  
        
        if self.non_linear_emb:
            print('non_linear embedding')
            self.emb_func = torch.nn.Sequential(
                                torch.nn.Linear(self.dim_att, self.dim_att//2),
                                torch.nn.ReLU(),
                                torch.nn.Linear(self.dim_att//2, 1),
                            )
        
        self.is_sigmoid = is_sigmoid
        if self.is_sigmoid:
            print("Sigmoid on attr score!!!")
        else:
            print("No sigmoid on attr score")




    # 对属性词向量进行标准化
    def compute_V(self):
        if self.normalize_V:  
            V_n = F.normalize(self.V)
        else:  
            V_n = self.V  
        return V_n


    def get_seenclass_prototype(self,in_package):
        # device = torch.device("cuda:{}".format(0) if torch.cuda.is_available() else "cpu")
        device = torch.device("cpu")
        batch_label = in_package['batch_label'].to(device)  # 图像标签
        batch_image_feature = in_package['F_att_v'].to(device)  # 图像特征
        unique_label = torch.unique(batch_label)
        prototypes = torch.empty(0).to(device)
        for i in unique_label:
            label_index = torch.nonzero(batch_label == i) # 对应的样本索引
            image_features = batch_image_feature[label_index]
            prototype_feature = torch.mean(image_features, dim=0)
            prototypes = torch.cat((prototypes,prototype_feature),dim = 0)
        return prototypes  # 二维张量，batch中的类别数*对应的2048维的类视觉原型

    def get_seenclass_att_feature(self,in_package):
        batch_label = in_package['batch_label']  # 图像标签
        batch_att_feature = in_package['F_p']  # 属性特征
        unique_label = torch.unique(batch_label)
        # device = torch.device("cuda:{}".format(0) if torch.cuda.is_available() else "cpu")
        device = torch.device("cpu")
        class_att_features = torch.empty(0).to(device)
        for i in unique_label:
            label_index = torch.nonzero(batch_label == i)
            att_features = batch_att_feature[label_index]
            att_feature = torch.mean(att_features, dim=0)
            class_att_features = torch.cat((class_att_features,att_feature),dim=0)
        return class_att_features  # 三维张量，batch中的类别数*对应的属性向量*对应的2048维的视觉特征

    def get_unseenclass_prototypes(self,att,seenclass_att_feature):
        unique_label = self.seenclass
        # print("seenclass_unique_label:", unique_label)
        class_att=self.att
        class_att[class_att<=0]=-1
        class_att[class_att>0]=1
        seen_class_att=att[self.seenclass] # 40*85
        unclass_att = att[self.unseenclass.long()]  # 10*85,小数，属性权重
        unseen_class_att=class_att[self.unseenclass.long()] # -1、1标识有无属性
        max_values, max_indices = torch.max(seen_class_att, dim=0)
        max_indices = unique_label[max_indices] # 真正label
        max_indices[max_indices == 0] = 100 # 标识可见类标签为0的情况
        max_indices=max_indices.repeat(self.unseenclass.shape[0],1)
        unseen_class_search_seen_att = max_indices * unseen_class_att # 存放不可见类所具有属性对应的可见类标签
        unseen_class_search_seen_att[unseen_class_search_seen_att == -100] = -1
        unseen_class_search_seen_att[unseen_class_search_seen_att == 100] = 0
        # seenclass_att_feature = self.get_seenclass_att_feature(in_package) # 40*85*2048
        unseen_prototypes = torch.empty(0)
        for i in range(unseen_class_search_seen_att.shape[0]): # 10个不可见类
            singleclass_att_feature = unseen_class_search_seen_att[i] # 取出第i行
            seenclass_att_index = torch.nonzero(singleclass_att_feature >= 0)[:,0] # 得到可见类对应的属性
            # print("seenclass_att_index\n",seenclass_att_index)
            seenclass_index=singleclass_att_feature[seenclass_att_index]
            # seenclass_index = singleclass_att_feature[torch.ge(singleclass_att_feature, 0)] # 返回大于等于0的布尔值,得到可见类对应的label
            # print("seenclass_index\n",seenclass_index)
            multi_att_feature = torch.empty(0)  # 存放一个不可见类所具有全部属性的视觉特征
            for j in range(seenclass_index.size(0)):
                label = seenclass_index[j].item()
                # print(int(label))
                inunique_label = torch.nonzero(unique_label == int(label))[0][0].item() # 取出uniquelabel中的label，得到某个可见类的label
                single_att_feature = seenclass_att_feature[inunique_label][seenclass_att_index[j]] # 从属性特征张量中取出某类某属性的视觉特征
                single_att_feature = torch.reshape(single_att_feature, (1, -1))
                multi_att_feature = torch.cat((multi_att_feature, single_att_feature), dim=0) # 所具有的属性数 * 2048
            # 要根据每个属性的权重，合成一个不可见类的类视觉原型
            have_atts = unclass_att[i][seenclass_att_index]  # 取出原始att矩阵中第i个不可见类所含有的若干属性
            have_atts = torch.reshape(have_atts, (1, -1))  # 1*58
            # have_atts = F.softmax(have_atts,dim=1)
            # print("have_atts:", have_atts)
            single_unseen_prototypes = torch.matmul(have_atts, multi_att_feature) # 1*2048
            unseen_prototypes = torch.cat((unseen_prototypes, single_unseen_prototypes), dim=0) # 10*2048
        return unseen_prototypes

    def get_unseenclass_prototypes1(self,att,seenclass_att_feature,W_3):
        att_w2v = self.init_w2v_att
        # unique_label = self.seenclass
        # print("seenclass_unique_label:", unique_label)
        class_att = self.att
        class_att[class_att<=0]=-1
        class_att[class_att>0]=1
        seen_class_att=att[self.seenclass] # 40*85
        unclass_att = att[self.unseenclass.long()]  # 10*85,小数，属性权重
        # unseen_class_att=class_att[self.unseenclass.long()] # -1、1标识有无属性
        max_values, max_indices = torch.topk(seen_class_att, k=2, dim=0)
        max_indices_T = max_indices.T
        max_values_T = max_values.T
        # seenclass_att_feature = self.get_seenclass_att_feature(in_package) # 40*85*2048
        unseen_prototypes = torch.empty(0)
        for i in range(unclass_att.shape[0]): # 10个不可见类
            singleclass_att = unclass_att[i] # 取出第i行
            seenclass_att_index = torch.nonzero(singleclass_att > 0)[:,0] # 得到每个不可见类拥有的属性
            V_N = att_w2v[seenclass_att_index]
            # print("seenclass_att_index\n",seenclass_att_index)
            everyclass_feature=torch.empty(0)
            for j in range(seenclass_att_index.shape[0]):
                everyatt=seenclass_att_index[j].item()       #得到每一个属性
                everyatt_toseenclass=max_indices_T[everyatt]          #得到每个属性在可见类中前5个最重要的类
                everyatt_feature = torch.empty(0)
                for k in range(max_indices_T.shape[1]):
                    everyatt_toseen_feature = seenclass_att_feature[everyatt_toseenclass[k]][everyatt]  # 从属性特征张量中取出某类某属性的视觉特征
                    everyatt_toseen_feature = torch.reshape(everyatt_toseen_feature, (1, -1))
                    everyatt_feature = torch.cat((everyatt_feature, everyatt_toseen_feature), dim=0)
                everyatt_toseen_weight=max_values_T[everyatt]     #得到每个属性对应的五个可见类的该属性的权重
                everyatt_toseen_weight = F.sigmoid(everyatt_toseen_weight)
                everyatt_toseen_weight=torch.reshape(everyatt_toseen_weight,(-1,1))
                everyatt_feature_total=torch.sum(everyatt_feature*everyatt_toseen_weight,dim=0)     #得到每个属性的属性特征
                everyatt_feature_total=torch.reshape(everyatt_feature_total,(1,-1))
                everyclass_feature = torch.cat((everyclass_feature, everyatt_feature_total), dim=0) # 这行不可见类的若干属性视觉特征
            A_p = torch.einsum('iv,vf,if->i', V_N, W_3, everyclass_feature) # 属性得分
            A_p = torch.sigmoid(A_p)  # 属性权重
            every_prototype = torch.einsum('if,i->f', everyclass_feature, A_p)  # 对属性聚合，得到图像特征  # compute attribute-based features
            every_prototype = torch.reshape(every_prototype,(1,-1))
            unseen_prototypes=torch.cat((unseen_prototypes,every_prototype),dim=0)
        return unseen_prototypes

    def get_unseenclass_prototypes2(self,att,seen_prototypes):
        unique_label = self.seenclass
        print("seenclass_unique_label:", unique_label)
        class_att=self.att
        class_att[class_att<=0]=-1
        class_att[class_att>0]=1
        seen_class_att=att[self.seenclass] # 40*85
        unclass_att = att[self.unseenclass.long()]  # 10*85,小数，属性权重
        unseen_class_att=class_att[self.unseenclass.long()] # -1、1标识有无属性
        max_values, max_indices = torch.topk(seen_class_att, k=5, dim=0)
        max_indices_T = max_indices.T
        max_values_T = max_values.T
        # seenclass_att_feature = self.get_seenclass_att_feature(in_package) # 40*85*2048
        unseen_prototypes = torch.empty(0)
        for i in range(unclass_att.shape[0]): # 10个不可见类
            singleclass_att = unclass_att[i] # 取出第i行
            seenclass_att_index = torch.nonzero(singleclass_att > 0)[:,0] # 得到每个不可见类拥有的属性
            # print("seenclass_att_index\n",seenclass_att_index)
            allatt_prototypes=torch.empty(0)
            for j in range(seenclass_att_index.shape[0]):
                everyatt=seenclass_att_index[j].item()       # 得到每一个属性
                everyatt_toseenclass=max_indices_T[everyatt]          # 得到每个属性在可见类中前5个最重要的类
                everyatt_seen_prototypes = torch.empty(0)
                for k in range(max_indices_T.shape[1]):
                    everyatt_toseen_prototypes = seen_prototypes[everyatt_toseenclass[k]]  # 取出某类的原型
                    everyatt_toseen_prototypes = torch.reshape(everyatt_toseen_prototypes, (1, -1))
                    everyatt_seen_prototypes = torch.cat((everyatt_seen_prototypes, everyatt_toseen_prototypes), dim=0)
                everyatt_toseen_weight=max_values_T[everyatt]     # 得到每个属性对应的五个可见类的该属性的权重
                # everyatt_toseen_weight = F.softmax(everyatt_toseen_weight) # 对属性值进行softmax得到权重
                everyatt_toseen_weight = torch.sigmoid(everyatt_toseen_weight)  # 对属性值进行sigmoid得到权重
                everyatt_toseen_weight = torch.reshape(everyatt_toseen_weight,(-1,1))
                everyatt_prototypes=torch.sum(everyatt_seen_prototypes*everyatt_toseen_weight,dim=0)     # 得到每个属性的属性特征
                everyatt_prototypes=torch.reshape(everyatt_prototypes,(1,-1))
                allatt_prototypes = torch.cat((allatt_prototypes, everyatt_prototypes), dim=0)  # 这行不可见类的若干属性视觉特征
            everyatt_weight=singleclass_att[seenclass_att_index]  # 属性权重
            everyatt_weight=torch.reshape(everyatt_weight, (-1,1))
            every_prototype=torch.sum(allatt_prototypes*everyatt_weight, dim=0)
            every_prototype=torch.reshape(every_prototype, (1,-1))
            print("every_prototype:", every_prototype.shape)
            unseen_prototypes=torch.cat((unseen_prototypes, every_prototype), dim=0)

        return unseen_prototypes

    def get_unseenclass_prototypes3(self,att,seenclass_att_feature):
        seen_class_att=att[self.seenclass] # 40*85
        unclass_att = att[self.unseenclass.long()]  # 10*85,小数，属性权重
        max_values, max_indices = torch.topk(seen_class_att, k=2, dim=0)
        max_indices_T = max_indices.T
        max_values_T = max_values.T
        unseen_prototypes = torch.empty(0)
        for i in range(unclass_att.shape[0]): # 10个不可见类
            singleclass_att = unclass_att[i] # 取出第i行
            seenclass_att_index = torch.nonzero(singleclass_att > 0)[:,0] # 得到每个不可见类拥有的属性
            everyclass_feature=torch.empty(0)
            for j in range(seenclass_att_index.shape[0]):
                everyatt=seenclass_att_index[j].item()       #得到每一个属性
                everyatt_toseenclass=max_indices_T[everyatt]          #得到每个属性在可见类中前5个最重要的类
                everyatt_feature = torch.empty(0)
                for k in range(max_indices_T.shape[1]):
                    everyatt_toseen_feature = seenclass_att_feature[everyatt_toseenclass[k]][everyatt]  # 从属性特征张量中取出某类某属性的视觉特征
                    everyatt_toseen_feature = torch.reshape(everyatt_toseen_feature, (1, -1))
                    everyatt_feature = torch.cat((everyatt_feature, everyatt_toseen_feature), dim=0)
                everyatt_toseen_weight=max_values_T[everyatt]     #得到每个属性对应的五个可见类的该属性的权重
                everyatt_toseen_weight = F.sigmoid(everyatt_toseen_weight)
                everyatt_toseen_weight=torch.reshape(everyatt_toseen_weight,(-1,1))
                everyatt_feature_total=torch.sum(everyatt_feature*everyatt_toseen_weight,dim=0)     #得到每个属性的属性特征
                everyatt_feature_total=torch.reshape(everyatt_feature_total,(1,-1))
                everyclass_feature = torch.cat((everyclass_feature, everyatt_feature_total), dim=0) # 这行不可见类的若干属性视觉特征
            # 要根据每个属性的权重，合成一个不可见类的类视觉原型
            have_atts = unclass_att[i][seenclass_att_index]  # 取出原始att矩阵中第i个不可见类所含有的若干属性
            have_atts = torch.reshape(have_atts, (1, -1))  # 1*58
            single_unseen_prototypes = torch.matmul(have_atts, everyclass_feature)  # 1*2048
            unseen_prototypes = torch.cat((unseen_prototypes, single_unseen_prototypes), dim=0)  # 10*2048
        return unseen_prototypes

    def euclidean_metric(self, a, b): # 计算样本与原型之间的欧式距离
        n = a.shape[0]
        m = b.shape[0]
        a = a.unsqueeze(1).expand(n, m, -1)
        b = b.unsqueeze(0).expand(n, m, -1)
        dist = ((a - b) ** 2).sum(dim=2)
        return dist

    def prototype_sample_loss(self,in_package):  # 样本与原型之间的损失，拉近样本与其同类原型，拉远样本与其不同类原型
        batch_label = in_package['batch_label'] # 图像标签
        unique_label = torch.unique(batch_label)
        # all_unique_label = self.seenclass
        # label_index = torch.nonzero(all_unique_label==unique_label)
        # print("label_index:",label_index)
        batch_image_feature = in_package['F_att_v'] # 图像特征
        # print("batch_image_feature shape:",batch_image_feature.shape)

        prototypes = self.get_seenclass_prototype(in_package)

        # 用已获得的原型重新训练
        Init_prototypes = torch.load('CUB_all_seenclass_prototypes.pth')


        dot = torch.matmul(batch_image_feature, prototypes.t())
        # 计算两个张量每一行的范数，得到一个2000x1和一个40x1的向量
        norm_a = torch.norm(batch_image_feature, dim=1, keepdim=True)
        norm_b = torch.norm(prototypes, dim=1, keepdim=True)
        # 用点积除以范数的乘积，得到一个6000x150的矩阵，表示余弦相似度
        sample_prototypes_sim = dot / (norm_a * norm_b.t())

        device = torch.device("cuda:{}".format(0) if torch.cuda.is_available() else "cpu")
        denominator = torch.tensor(0.0).to(device)
        batch_inunique_label=[]
        for i in range(batch_image_feature.shape[0]):
            sample_label = batch_label[i]
            sample_inunique_label=torch.nonzero(unique_label==sample_label)[0][0]
            batch_inunique_label.append(sample_inunique_label)
            # batch_inunique_label=torch.cat((batch_inunique_label,sample_inunique_flatten_label),dim=0)
            ii=torch.tensor(i)
            denominator += sample_prototypes_sim[ii][sample_inunique_label]
        batch_inunique_label=torch.tensor(batch_inunique_label)
        # print(batch_inunique_label)
        # print(batch_inunique_label.shape)
        total_sim = torch.sum(sample_prototypes_sim)
        numerator = total_sim-denominator

        loss1 = numerator/denominator

        # loss2 = F.cross_entropy(sample_prototypes_sim,batch_inunique_label)

        loss = loss1


        # out_package = {'prototype_sample_loss', loss}

        return loss

    def prototypes_loss(self,in_package): # 原型之间的损失，拉远不同类的原型
        prototypes = self.get_seenclass_prototype(in_package)
        dot = torch.matmul(prototypes, prototypes.t())

        # 计算两个张量每一行的范数，得到一个2000x1和一个40x1的向量
        norm_a = torch.norm(prototypes, dim=1, keepdim=True)
        norm_b = torch.norm(prototypes, dim=1, keepdim=True)

        # 用点积除以范数的乘积，得到一个2000x40的矩阵，表示余弦相似度
        prototypes_prototypes_sim = dot / (norm_a * norm_b.t())
        device = torch.device("cuda:{}".format(0) if torch.cuda.is_available() else "cpu")
        same_prototypes = torch.tensor(0.0).to(device)
        for i in range(prototypes.shape[0]):
            for j in range(prototypes.shape[0]):
                if i==j:
                    same_prototypes += prototypes_prototypes_sim[i][j]
        total_sim = torch.sum(prototypes_prototypes_sim)
        loss = (total_sim - same_prototypes)/2/prototypes.shape[0]
        out_package = {'prototypes_loss', loss}
        return loss

    def samples_contrastive_loss(self,in_package):
        batch_label = in_package['batch_label']  # 图像标签
        batch_image_feature = in_package['F_att_v']  # 图像特征 2048维

        same_label_samples = torch.tensor(0.0)
        unsame_label_samples = torch.tensor(0.0)
        distance = torch.cdist(batch_image_feature,batch_image_feature,p=2)
        print(distance)
        flag = torch.zeros((batch_label.shape[0], batch_label.shape[0]))    #同一类的相应位置为1
        flag1 = torch.zeros((batch_label.shape[0], batch_label.shape[0]))  # 不同类的相应位置为1
        for i in range(batch_label.shape[0]):
            for j in range(i+1,batch_label.shape[0]):
                if batch_label[i]==batch_label[j]:
                    flag[i][j]=1
                    flag[j][i]=1
                else:
                    flag1[i][j]=1
                    flag1[j][i]=1
        same_distance=distance*flag
        same_label_samples=torch.mean(same_distance)
        unsame_distance=torch.clamp(60.0 - distance, min=0.0)*flag1
        unsame_label_samples=torch.mean(unsame_distance)
        loss=same_label_samples+unsame_label_samples

        # for i in range(batch_label.shape[0]):
        #     for j in range(batch_label.shape[0]):
        #         if batch_label[i]==batch_label[j]: # 两个图像具有相同label
        #             # i_index = torch.where(batch_label == i)
        #             # j_index = torch.where(batch_label == j)
        #             # euclidean_distance = F.pairwise_distance(batch_image_feature[i_index], batch_image_feature[j_index], keepdim=True)
        #             # same_label_samples += torch.pow(torch.clamp(2.0 - euclidean_distance, min=0.0), 2)
        #             batch_image_feature1=torch.reshape(batch_image_feature[i],[1,-1])
        #             batch_image_feature2 = torch.reshape(batch_image_feature[j], [1, -1])
        #             euclidean_distance = F.pairwise_distance(batch_image_feature1, batch_image_feature2)
        #             same_label_samples += torch.pow(euclidean_distance, 2)[0]
        #         else:
        #             # i_index = torch.where(batch_label == i)
        #             # j_index = torch.where(batch_label == j)
        #             # euclidean_distance = F.pairwise_distance(batch_image_feature[i_index], batch_image_feature[j_index], keepdim=True)
        #             # unsame_label_samples += torch.pow(euclidean_distance, 2)
        #             batch_image_feature1 = torch.reshape(batch_image_feature[i], [1, -1])
        #             batch_image_feature2 = torch.reshape(batch_image_feature[j], [1, -1])
        #             euclidean_distance = F.pairwise_distance(batch_image_feature1, batch_image_feature2)
        #             unsame_label_samples += torch.pow(torch.clamp(2.0 - euclidean_distance, min=0.0), 2)[0]
        # loss = same_label_samples + unsame_label_samples
        return loss


    def compute_total_loss(self,in_package):
        prototype_sample_loss = self.prototype_sample_loss(in_package)
        prototypes_loss = self.prototypes_loss(in_package)
        # samples_loss = self.samples_contrastive_loss(in_package)
        loss = prototype_sample_loss + prototypes_loss # + samples_loss
        out_package = {'loss': loss, 'loss_PS': prototype_sample_loss,#'loss_sim':simloss,'cls':cls,
                       'loss_PP': prototypes_loss}
        return out_package


      
    def forward(self,Fs,batch_class_att):
        
        if self.is_conv:
            Fs = self.conv1(Fs)
            Fs = self.conv1_bn(Fs)
            Fs = F.relu(Fs)
        
        shape = Fs.shape
        Fs = Fs.reshape(shape[0],shape[1],shape[2]*shape[3])
        batch_class_att1=batch_class_att.unsqueeze(2)
        batch_class_att2=batch_class_att1.repeat(1,1,self.dim_v)
        
        R = Fs.size(2)  # 区域数量
        # B = Fs.size(0)  # 批次大小
        V_n = self.compute_V() # 标准化的属性词向量 85*300

        if self.normalize_F and not self.is_conv:  
            Fs = F.normalize(Fs,dim=1)  # 对区域视觉特征进行标准化处理


        ## compute Dense Attention
        A = torch.einsum('biv,iv,vf,bfr->bir', batch_class_att2, V_n, self.W_2, Fs)  # 属性语义与区域之间的兼容性


        # print("softmax前的区域：",A)
        A_mask = batch_class_att.unsqueeze(2)
        A_mask = A_mask.repeat(1,1,R)


        # print("A_mask:",A_mask)

        A[A==0]=-1000
        A1 = torch.softmax(A, dim= -1) # 获得每个属性对应的区域重要性的概率分布                  # compute an attention map for each attribute
        # A1 = torch.sigmoid(A)
        # print("softmax后的区域权重：", A1)
        A2 = torch.einsum('bir,bir->bir', A1, A_mask)
        # print("A_mask后的：",A2)

        F_p = torch.einsum('bir,bfr->bif',A2,Fs)   # 对区域聚合，得到属性特征  # compute attribute-based features
        # print("属性特征：",F_p)

        ## compute Attention over Attribute
        A_p = torch.einsum('biv,iv,vf,bif->bi',batch_class_att2,V_n,self.W_3,F_p) # 属性得分，后续得到属性权重
        print("原始A_p:",A_p)
        print("A_p每行中大于0的元素个数:\n",torch.sum(A_p>0, dim=1))
        # A_p_mask = A_p.clone()
        # print("A0:\n", A_p_mask)
        # A_p_mask[A_p_mask == 0] = 0    #以前的
        # A_p_mask[A_p_mask != 0] = 1
        # A_p = torch.sigmoid(A_p) # 属性权重
        A_p[A_p==0]=-1000
        A_p = torch.sigmoid(A_p) # 属性权重

        # A_p = torch.softmax(A_p, dim=-1)
        print("softmax A_p:\n",A_p)

        # print("A:\n", A_p_mask)
        #
        # A_p = torch.einsum('bi,bi->bi',A_p,A_p_mask)
        ##
        print("属性权重:\n", A_p)
        F_att_v = torch.einsum('bif,bi->bf', F_p, A_p)   # 对属性聚合，得到图像特征  # compute attribute-based features

        package = {'F_p':F_p,'F_att_v':F_att_v}

        return package  
