import os,sys
# pwd = os.getcwd()
# parent = '/'.join(pwd.split('/')[:-1])
# sys.path.insert(0,parent)
# os.chdir(parent)
#%%


print('-'*30)
print(os.getcwd())
print('-'*30)
#%%
import torch
import torch.optim as optim
import torch.nn as nn
import pandas as pd
from core.DAZLE_AWA2 import DAZLE
# from core.DAZLE import DAZLE
from core.AWA2DataLoader import AWA2DataLoader
from core.helper_func import eval_zs_gzsl,visualize_attention#,get_attribute_attention_stats
from global_setting import NFS_path
import importlib
import numpy as np
import torchvision.models as models
import matplotlib.pyplot as plt

print(torch.__version__)

idx_GPU = 0
# device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")
torch.backends.cudnn.benchmark = True


dataloader = AWA2DataLoader(NFS_path,device)


def get_lr(optimizer):
    lr = []
    for param_group in optimizer.param_groups:
        lr.append(param_group['lr'])
    return lr


seed = 214#214
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
np.random.seed(seed)

batch_size = 2000
nepoches = 40
niters = dataloader.ntrain * nepoches//batch_size # 23527*40//2000 = 470,取整
dim_f = 2048 # 特征维度
dim_v = 300 # 属性词向量的维度

# 加载数据
init_w2v_att = dataloader.w2v_att # 属性词向量，shape为85*300
att = dataloader.att #dataloader.normalize_att# 类属性，50*85

normalize_att = dataloader.normalize_att
#assert (att.min().item() == 0 and att.max().item() == 1)

trainable_w2v = True
lambda_ = 0.1 #0.1
bias = 0
prob_prune = 0
uniform_att_1 = False
uniform_att_2 = True

seenclass = dataloader.seenclasses
unseenclass = dataloader.unseenclasses
desired_mass = 1
report_interval = niters//nepoches # 11

model = DAZLE(dim_f,dim_v,init_w2v_att,att,normalize_att,
            seenclass,unseenclass,
            lambda_,
            trainable_w2v,normalize_V=True,normalize_F=True,is_conservative=True,
            uniform_att_1=uniform_att_1,uniform_att_2=uniform_att_2,
            prob_prune=prob_prune,desired_mass=desired_mass, is_conv=False,
            is_bias=True)
model.to(device)

setup = {'pmp':{'init_lambda':0.1,'final_lambda':0.1,'phase':0.8},
         'desired_mass':{'init_lambda':-1,'final_lambda':-1,'phase':0.8}}
print(setup)

params_to_update = []
params_names = []
for name,param in model.named_parameters(): # 迭代访问模型的各个参数
    if param.requires_grad == True:
        params_to_update.append(param)
        params_names.append(name)
        print("\t",name)
#%%
lr = 0.0001
weight_decay = 0.0001#0.000#0.#
momentum = 0.#0.#
#%%
lr_seperator = 1
lr_factor = 1
print('default lr {} {}x lr {}'.format(params_names[:lr_seperator],lr_factor,params_names[lr_seperator:]))
optimizer  = optim.RMSprop(params_to_update ,lr=lr,weight_decay=weight_decay, momentum=momentum)
print('-'*30)
print('learing rate {}'.format(lr))
print('trainable V {}'.format(trainable_w2v))
print('lambda_ {}'.format(lambda_))
print('optimized seen only')
print('optimizer: RMSProp with momentum = {} and weight_decay = {}'.format(momentum,weight_decay))
print('-'*30)

for i in range(0, niters): # 迭代样本数次
    model.train()
    optimizer.zero_grad()

    batch_label, batch_feature, batch_att,batch_class_att = dataloader.next_batch(batch_size)
    # print(batch_class_att) # 40个label
    out_package = model(batch_feature,batch_class_att) # 前向传播batch_feature

    in_package = out_package
    in_package['batch_label'] = batch_label
    in_package['batch_class_att'] = batch_class_att

    out_package = model.compute_total_loss(in_package)
    loss, loss_PS,loss_PP = out_package['loss'], out_package['loss_PS'], out_package['loss_PP']

    loss.backward()
    optimizer.step()
    if i % report_interval == 0:
        print('-' * 30)
        stats_package = {'iter': i, 'loss': loss.item(), 'loss_PS': loss_PS.item(), 'loss_PP':loss_PP.item()}
        print(stats_package)
        torch.save(model.state_dict(),
                   './AWA2_main_model_weights/AWA2_main_model_weights_withweights_10_7_' + str(batch_size) + 'b_' + str(
                       niters) + 'e_' + str(i + 1) + '.pth')

# torch.save(model.state_dict(), 'model_weights.pth') # save the model's state_dict to a file
# torch.save(model.state_dict(), './AWA2_main_model_weights/AWA2_main_model_weights10_2_'+str(batch_size)+'b_'+str(niters)+'e_'+str(i+1)+'.pth')



# unseen_data = torch.load("../GAN/unseen_samples_with_gan.pth")
# startindex=0
# for i in range(0, niters): # 迭代样本数次
#     model.train()
#     optimizer.zero_grad()
#
#     batch_label, batch_feature, batch_att,batch_class_att = dataloader.next_batch(batch_size)
#
#     unseen_feature,unseen_label, unseen_class_att,startindex = dataloader.next_batch_unseen_gan(unseen_data,startindex,500,batch_size//seenclass.size(0))
#     # print(batch_class_att) # 40个label
#     batch_label=torch.cat((batch_label,unseen_label),dim=0)
#     batch_class_att=torch.cat((batch_class_att,unseen_class_att),dim=0)
#     batch_feature=torch.cat((batch_feature,unseen_feature),dim=0)
#     out_package = model(batch_feature,batch_class_att) # 前向传播batch_feature
#
#     in_package = out_package
#     in_package['batch_label'] = batch_label
#     in_package['batch_class_att'] = batch_class_att
#
#     out_package = model.compute_total_loss(in_package)
#     loss, loss_PS, loss_PP = out_package['loss'], out_package['loss_PS'], out_package['loss_PP']
#
#     loss.backward()
#     optimizer.step()
#     if i % report_interval == 0:
#         print('-' * 30)
#         stats_package = {'iter': i, 'loss': loss.item(), 'loss_PS': loss_PS.item(), 'loss_PP': loss_PP.item(), 'loss_SS': loss_SS.item()}
#         print(stats_package)
#
# # torch.save(model.state_dict(), 'model_weights.pth') # save the model's state_dict to a file
# torch.save(model.state_dict(), 'AWA2_main_model_weights_withSS_withgan_unseen.pth')



