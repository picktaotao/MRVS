import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.optim as optim
import scipy.io as sio
from torchvision import models
from global_setting import NFS_path
from torchvision import datasets, transforms
from core.AWA2DataLoader import AWA2DataLoader
from torch.utils.data import Dataset, DataLoader
import numpy as np
from PIL import Image
import re
from torchmetrics import F1Score

from sklearn.metrics.pairwise import euclidean_distances

import os,sys
pwd = os.getcwd() # 获取当前工作目录的路径
sys.path.insert(0,pwd) # 将当前工作目录添加到sys.path列表的最前面，首先在该目录中搜索


# 定义要遍历的文件夹
folder1 = "F:/cvpr20_DAZLE/data/AWA2/Animals_with_Attributes2/train"
names = os.listdir(folder1) # 子文件夹和子文件的名称
subfolders = [] # 存放每个类的名称
for name in names:
    path = os.path.join(folder1, name)
    path = path.replace("\\", "/")
    if os.path.isdir(path):
        subfolders.append(name)
print(subfolders)
# 定义一个空列表，用于保存路径
path_list = [] # train文件夹中的可见类图像路径
image_label = [] # 每个图像对应的label
# 使用 os.walk 函数遍历文件夹
for root, dirs, files in os.walk(folder1):
    # 遍历当前目录下的文件
    for file in files:
        # 拼接文件的完整路径
        file_path = os.path.join(root, file)
        # 将路径添加到列表中
        file_path = file_path.replace("\\", "/")
        path_list.append(file_path)
        pattern = "|".join([x.replace("+", "\+") for x in subfolders])
        match = re.search(pattern, file_path)
        if match:
            first_match = match.group()
            image_label.append(first_match)
        else:
            print("No match found")
            print(file_path)
# print(len(image_label)) # 29409
# print(len(path_list))

folder2 = "H:/cvpr20_DAZLE/data/AWA2/Animals_with_Attributes2/JPEGImages"
names1 = os.listdir(folder2) # 子文件夹和子文件的名称
subfolders1 = [] # 存放每个类的名称
for name in names1:
    path = os.path.join(folder2, name)
    path = path.replace("\\", "/")
    if os.path.isdir(path):
        subfolders1.append(name)
# 定义一个空列表，用于保存路径
path_list1 = [] # 所有类的图像路径
image_label1 = [] # 所有图像对应的label
# 使用 os.walk 函数遍历文件夹
for root, dirs, files in os.walk(folder2):
    # 遍历当前目录下的文件
    for file in files:
        # 拼接文件的完整路径
        file_path = os.path.join(root, file)
        # 将路径添加到列表中
        file_path = file_path.replace("\\", "/")
        path_list1.append(file_path)
        pattern = "|".join([x.replace("+", "\+") for x in subfolders1])
        match = re.search(pattern, file_path)
        if match:
            first_match = match.group()
            image_label1.append(first_match)
        else:
            print("No match found")
            print(file_path)
print(len(path_list1))
print(len(image_label1))
image_unique_label = list(set(image_label1))
image_unique_label = sorted(image_unique_label, key=image_label1.index)  # 50个字符串的列表
# print(image_unique_label)

idx_GPU = 0
device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")
dataloader = AWA2DataLoader(NFS_path,device)
labels_order = dataloader.labels_order  # 50个类的原有顺序
# print(labels_order)
labelname_label_dict = dict(zip(image_unique_label, labels_order)) # 50个类别名和对应的label数值
print(labelname_label_dict)
image_label_values = [labelname_label_dict.get(key) for key in image_label] # image_label是40个可见类的所有样本的类名
prototypes_label_1dim = torch.tensor(np.unique(image_label_values)).to(device) # 原型对应的label是从小到大排列的
prototypes_label = torch.reshape(prototypes_label_1dim, (1, -1)) # 将张量变为 1*40
# prototypes_label = prototypes_label.repeat(64, 1) # 32*40
# print(image_label_values)
# print(np.unique(image_label_values))
'''至此，train文件夹里40个可见类的样本路径path_list和样本标签值image_label_values就获得了。
   用于后续，读取样本图像，以及损失计算
'''
dataset="AWA2"
split_path = os.path.join(NFS_path,'data/xlsa17/data/{}/att_splits.mat'.format(dataset))
matcontent = sio.loadmat(split_path)
att = matcontent['att'].T
att[att<0]=0
att[att>0]=1
f1score=F1Score(task="multilabel",average="micro",num_labels=att.shape[1]).to(device)


class CustomedDataset(Dataset): # 用于加载图像数据集，并提供图像数据增强功能
    def __init__(self, file_paths, image_labels,transform=None):
        self.image_files = file_paths
        self.image_label_values = image_labels
        self.transform = transform

    def __len__(self):
        return len(self.image_files) # 返回数据集大小=图像数目

    def __getitem__(self, idx):
        image_file = self.image_files[idx]
        image_label = self.image_label_values[idx]
        image = Image.open(image_file)
        if image.mode == 'L':
            image=image.convert('RGB')
        if self.transform:
            image = self.transform(image)
        return (image,image_label)

input_size = 224
data_transforms = transforms.Compose([
        transforms.Resize(input_size),
        transforms.CenterCrop(input_size),
        transforms.ToTensor(),
        # [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]均值和标准差
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
# 划分训练集和验证集
train_list = path_list[:20000]
train_label = image_label_values[:20000]
val_list = path_list[20000:]
val_label = image_label_values[20000:]
train_dataset = CustomedDataset(train_list,train_label,data_transforms)
data = torch.utils.data.DataLoader(train_dataset, batch_size=64, shuffle=True,num_workers=0)


# 定义一个卷积神经网络模型，使用预训练的resnet18作为特征提取器

model = torchvision.models.resnet101(pretrained=True) # 加载预训练的resnet18模型
for param in model.parameters(): # 冻结模型参数，不进行梯度更新
    param.requires_grad = False
num_ftrs = model.fc.in_features # 获取模型最后一层的输入特征数
model.fc = nn.Linear(num_ftrs, att.shape[1]) # 替换模型最后一层为一个全连接层，输出属性的概率
model.to(device)
# 定义一个损失函数和优化器，使用二元交叉熵损失和随机梯度下降优化器
criterion = nn.BCEWithLogitsLoss() # 二元交叉熵损失，适用于多标签分类问题
optimizer = optim.RMSprop(model.fc.parameters(), lr=0.001, weight_decay=0.0001,momentum=0.9) # 随机梯度下降优化器，只优化最后一层的参数

# 训练模型，进行10个周期
for epoch in range(10):

    running_loss = 0.0 # 记录累计损失
    for i_batch, batch in enumerate(data): # 遍历训练数据集
        print("第{}次训练".format(i_batch))
        model.train()
        optimizer.zero_grad() # 清零梯度缓存
        imgs = batch[0].to(device)  # 32个图像样本
        # print(imgs.shape)
        imgs_labels1 = batch[1].clone().to(device)  # 32个label   # 获取输入图片和属性标签
        att_label=att[imgs_labels1.cpu()]
        att_label=torch.from_numpy(att_label).to(device)

        outputs = model(imgs) # 前向传播，得到输出概率

        loss = criterion(outputs, att_label) # 计算损失函数
        loss.backward() # 反向传播，计算梯度
        optimizer.step() # 更新参数
        running_loss += loss.item() # 累加损失

        if i_batch % 20 == 19:    # 每2000个批次打印一次平均损失

            print('[%d, %5d] loss: %.3f' %
            (epoch + 1, i_batch + 1, running_loss / 20))

            running_loss = 0.0
    model.eval()
    # 遍历验证数据集，计算准确率等指标
    val_dataset = CustomedDataset(val_list, val_label, data_transforms)
    val_data = torch.utils.data.DataLoader(val_dataset, batch_size=60, shuffle=False, num_workers=0)
    equal_count = 0  # 记录预测标签正确的数量
    for i_batch, batch in enumerate(val_data):
        print("第{}次验证".format(i_batch))
        images = batch[0].to(device)
        # print(imgs.shape)
        imgs_labels_1dim = batch[1].clone().to(device)  # 32个label
        # print(imgs_labels_1dim.shape)
        img_att_label=att[imgs_labels_1dim.cpu()]
        img_att_label=torch.from_numpy(img_att_label).to(device)
        pred_output = model(images)
        pred_output = pred_output.to(device)
        score=f1score(pred_output,img_att_label)
    # 打印每轮的结果，比如损失值和准确率等
    print(f"Epoch {epoch}, loss: {loss.item()}, score: {score}")

print('Finished Training')
torch.save(model.state_dict(), 'attribute_model_weights.pth') # save the model's state_dict to a file
