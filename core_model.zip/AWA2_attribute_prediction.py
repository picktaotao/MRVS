import torch
from core.AWA2DataLoader import AWA2DataLoader
from global_setting import NFS_path
from core.DAZLE import DAZLE
import torchvision
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import scipy.io as sio
from PIL import Image
import numpy as np
import os, sys

pwd = os.getcwd()  # 获取当前工作目录的路径
sys.path.insert(0, pwd)  # 将当前工作目录添加到sys.path列表的最前面，首先在该目录中搜索
from torchvision import transforms
import torch.nn.functional as F

idx_GPU = 0
# device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")
torch.backends.cudnn.benchmark = True

dataloader = AWA2DataLoader(NFS_path, device)
dataset = 'AWA2'
img_dir = os.path.join(NFS_path, 'data/{}/'.format(dataset))
file_paths = os.path.join(NFS_path, 'data/xlsa17/data/{}/res101.mat'.format(dataset))
split_path = os.path.join(NFS_path, 'data/xlsa17/data/{}/att_splits.mat'.format(dataset))

batch_size = 50
niters = dataloader.ntrain // batch_size  # 7057//200 = 35
dim_f = 2048  # 特征维度
dim_v = 300  # 属性词向量的维度
init_w2v_att = dataloader.w2v_att
att = dataloader.att

normalize_att = dataloader.normalize_att
lambda_ = 0.1  # 0.1
seenclass = dataloader.seenclasses
unseenclass = dataloader.unseenclasses
uniform_att_1 = False
uniform_att_2 = True
trainable_w2v = True

# 2、加载属性模型
attribute_model = torchvision.models.resnet101(pretrained=True)  # 加载预训练的resnet101模型
for param in attribute_model.parameters():  # 冻结模型参数，不进行梯度更新
    param.requires_grad = False
num_ftrs = attribute_model.fc.in_features  # 获取模型最后一层的输入特征数
# attribute_model.fc = nn.Linear(num_ftrs, att.shape[1])  # 替换模型最后一层为一个全连接层，输出属性的概率
attribute_model.fc = nn.Linear(num_ftrs, att.shape[1]) # 替换模型最后一层为一个全连接层，输出属性的概率
# newlayer = nn.Linear(num_ftrs//2, num_ftrs//4)
# newlayer1 = nn.Linear(num_ftrs//4, att.shape[1])
# attribute_model = nn.Sequential(attribute_model,newlayer,newlayer1)
# attribute_model.load_state_dict(torch.load('CUB_attribute_model_weights.pth'))
attribute_model.load_state_dict(torch.load('attribute_model_weights.pth'))
attribute_model.eval()
attribute_model.to(device)


# 4、加载不可见类的图像文件
matcontent1 = sio.loadmat(file_paths)  # 包含图片路径
image_files = matcontent1['image_files']  # 加载出文件路径
matcontent2 = sio.loadmat(split_path)
train_seen_loc = matcontent2['trainval_loc'].squeeze() - 1
test_seen_loc = matcontent2['test_seen_loc'].squeeze() - 1
test_unseen_loc = matcontent2['test_unseen_loc'].squeeze() - 1

train_seen_img_files = image_files[train_seen_loc]  # 不可见类中的可见类图像文件路径
test_seen_img_files = image_files[test_seen_loc]  # 不可见类中的可见类图像文件路径
test_unseen_img_files = image_files[test_unseen_loc]  # 不可见类中的不可见类图像文件路径

train_seen_files = []
train_seen_img_files = train_seen_img_files.flatten()  # 展成一维
for s in train_seen_img_files:
    s = os.path.join(img_dir, '/'.join(s[0].split('/')[5:]))
    train_seen_files.append(s)

test_seen_files = []
test_seen_img_files = test_seen_img_files.flatten()  # 展成一维
for s in test_seen_img_files:
    s = os.path.join(img_dir, '/'.join(s[0].split('/')[5:]))
    test_seen_files.append(s)

test_unseen_files = []
test_unseen_img_files = test_unseen_img_files.flatten()  # 展成一维
for s in test_unseen_img_files:
    s = os.path.join(img_dir, '/'.join(s[0].split('/')[5:]))
    test_unseen_files.append(s)
print('test_unseen_files shape:', len(test_unseen_files))


class CustomedDataset(Dataset):  # 用于加载图像数据集，并提供图像数据增强功能
    def __init__(self, test_unseen_files, transform=None):
        self.image_files = test_unseen_files
        self.transform = transform

    def __len__(self):
        return len(self.image_files)  # 返回数据集大小=图像数目

    def __getitem__(self, idx):
        image_file = self.image_files[idx]
        image = Image.open(image_file)
        if image.mode == 'L':
            image = image.convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image


input_size = 224
data_transforms = transforms.Compose([
    transforms.Resize(input_size),
    transforms.CenterCrop(input_size),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

# train_seen_image = CustomedDataset(train_seen_files, data_transforms)
# data = torch.utils.data.DataLoader(train_seen_image, batch_size=64, shuffle=False, num_workers=0)
# # 预测属性
# train_seen_attributes = torch.empty(0).to(device)
# for i_batch, imgs in enumerate(data):  # 遍历训练数据集
#     print("第{}批".format(i_batch))
#     imgs = imgs.to(device)
#     pred_attribute = attribute_model(imgs)  # 64*312
#     pred_attribute = torch.sigmoid(pred_attribute)
#
#     y = torch.gt(pred_attribute, 0.5)
#     print(torch.sum(y,dim=1))
#     pred_attributes = torch.where(y, torch.tensor(1), torch.tensor(0))
#     train_seen_attributes = torch.cat((train_seen_attributes, pred_attributes), dim=0).int()  # 2967*312
# print("train_seen_attributes:\n", train_seen_attributes)
# torch.save(train_seen_attributes, "../pred_attribute/AWA2_train_seen_attribute_1loss.pth")
#
#
#
test_seen_image = CustomedDataset(test_seen_files, data_transforms)
data1 = torch.utils.data.DataLoader(test_seen_image, batch_size=64, shuffle=False, num_workers=0)
# 预测属性
test_seen_attributes = torch.empty(0).to(device)
for i_batch, imgs in enumerate(data1):  # 遍历训练数据集
    print("第{}批".format(i_batch))
    imgs = imgs.to(device)
    pred_attribute = attribute_model(imgs)  # 64*312
    pred_attribute = torch.sigmoid(pred_attribute)

    y = torch.gt(pred_attribute, 0.5)
    pred_attributes = torch.where(y, torch.tensor(1), torch.tensor(0))
    test_seen_attributes = torch.cat((test_seen_attributes, pred_attributes), dim=0).int()  # 2967*312
print("test_seen_attributes:\n", test_seen_attributes)
torch.save(test_seen_attributes, "../pred_attribute/AWA2_test_seen_attribute_1loss.pth")


test_unseen_image = CustomedDataset(test_unseen_files, data_transforms)
data2 = torch.utils.data.DataLoader(test_unseen_image, batch_size=64, shuffle=False, num_workers=0)
# 预测属性
test_unseen_attributes = torch.empty(0).to(device)
for i_batch, imgs in enumerate(data2):  # 遍历训练数据集
    print("第{}批".format(i_batch))
    imgs = imgs.to(device)
    pred_attribute = attribute_model(imgs)  # 64*312
    pred_attribute = torch.sigmoid(pred_attribute)

    y = torch.gt(pred_attribute, 0.5)

    pred_attributes = torch.where(y, torch.tensor(1), torch.tensor(0))

    test_unseen_attributes = torch.cat((test_unseen_attributes, pred_attributes), dim=0).int()  # 2967*312
print("unseen_attributes:\n", test_unseen_attributes)
torch.save(test_unseen_attributes, "../pred_attribute/AWA2_test_unseen_attribute_1loss.pth")


