import torch
from core.CUB50_DataLoader import CUB50DataLoader
from global_setting import NFS_path
from core.DAZLE import DAZLE
import torchvision
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import scipy.io as sio
from PIL import Image
import numpy as np
import os, sys
import re
from core.data_split import data_split

pwd = os.getcwd()  # 获取当前工作目录的路径
sys.path.insert(0, pwd)  # 将当前工作目录添加到sys.path列表的最前面，首先在该目录中搜索
from torchvision import transforms
device = torch.device("cpu")
torch.backends.cudnn.benchmark = True

dataloader = CUB50DataLoader(NFS_path, device)

batch_size = 200
niters = dataloader.ntrain // batch_size  # 2338//200 = 11
dim_f = 2048  # 特征维度
# dim_v = 100  # 属性词向量的维度
init_w2v_att = dataloader.w2v_att
att = dataloader.att
# att[att<=0.01]=0
att[att>0]=1
print("原始属性")
print(torch.sum(att,dim=1))

lambda_ = 0.1  # 0.1
seenclass = dataloader.seenclasses
unseenclass = dataloader.unseenclasses
uniform_att_1 = False
uniform_att_2 = True
trainable_w2v = True

# 2、加载属性模型
attribute_model = torchvision.models.resnet101(pretrained=True)  # 加载预训练的resnet101模型
for param in attribute_model.parameters():  # 冻结模型参数，不进行梯度更新
    param.requires_grad = False
num_ftrs = attribute_model.fc.in_features  # 获取模型最后一层的输入特征数
# attribute_model.fc = nn.Linear(num_ftrs, att.shape[1])  # 替换模型最后一层为一个全连接层，输出属性的概率
attribute_model.fc = nn.Linear(num_ftrs, att.shape[1]) # 替换模型最后一层为一个全连接层，输出属性的概率
# newlayer = nn.Linear(num_ftrs//2, num_ftrs//4)
# newlayer1 = nn.Linear(num_ftrs//4, att.shape[1])
# attribute_model = nn.Sequential(attribute_model,newlayer,newlayer1)
# attribute_model.load_state_dict(torch.load('CUB_attribute_model_weights.pth'))
attribute_model.load_state_dict(torch.load('CUB50_attribute_model_weights9_5.pth'))
attribute_model.eval()
attribute_model.to(device)

#4、加载不可见类的图像文件
folder1 = "D:/CUB50"
names = os.listdir(folder1) # 子文件夹和子文件的名称
subfolders = [] # 存放每个类的名称
for name in names:
    path = os.path.join(folder1, name)
    path = path.replace("\\", "/")
    if os.path.isdir(path):
        subfolders.append(name)
print(subfolders)
# 定义一个空列表，用于保存路径
path_list = []  # train文件夹中的可见类图像路径
image_label = []  # 每个图像对应的label
# 使用 os.walk 函数遍历文件夹
for root, dirs, files in os.walk(folder1):
    # 遍历当前目录下的文件
    for file in files:
        # 拼接文件的完整路径
        file_path = os.path.join(root, file)
        # 将路径添加到列表中
        file_path = file_path.replace("\\", "/")
        path_list.append(file_path)
        pattern = "|".join([x.replace("+", "\+") for x in subfolders])
        match = re.search(pattern, file_path)
        if match:
            first_match = match.group()
            image_label.append(first_match)
        else:
            print("No match found")
            print(file_path)
print(len(image_label)) # 2936
print(len(path_list)) # 图像的路径

image_files = np.array(path_list)  # 包含图片路径
train_seen , test_seen = data_split()
train_seen_loc = train_seen
test_seen_loc = test_seen
test_unseen_loc = np.arange(2338,2936)
test_unseen_img_files = image_files[test_unseen_loc]  # 不可见类中的不可见类图像文件路径
train_seen_img_files = image_files[train_seen_loc]
test_seen_img_files = image_files[test_seen_loc]

class CustomedDataset(Dataset):  # 用于加载图像数据集，并提供图像数据增强功能
    def __init__(self, test_unseen_files, transform=None):
        self.image_files = test_unseen_files
        self.transform = transform

    def __len__(self):
        return len(self.image_files)  # 返回数据集大小=图像数目

    def __getitem__(self, idx):
        image_file = self.image_files[idx]
        image = Image.open(image_file)
        if image.mode == 'L':
            image = image.convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image


input_size = 224
data_transforms = transforms.Compose([
    transforms.Resize(input_size),
    transforms.CenterCrop(input_size),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

# 训练集属性预测
# train_seen_image = CustomedDataset(train_seen_img_files, data_transforms)
# data = torch.utils.data.DataLoader(train_seen_image, batch_size=64, shuffle=False, num_workers=0)
# # 预测属性
# train_seen_attributes = torch.empty(0).to(device)
# for i_batch, imgs in enumerate(data):  # 遍历训练数据集
#     print("第{}批".format(i_batch))
#     imgs = imgs.to(device)
#     pred_attribute = attribute_model(imgs)  # 64*312
#     pred_attribute = torch.sigmoid(pred_attribute)
#
#     y = torch.gt(pred_attribute, 0.5)
#     print(torch.sum(y,dim=1))
#     # tensor([[False,  True,  True],
#     #         [False,  True,  True]])
#     # 沿着第一个维度（行）对布尔张量求和，True为1，False为0
#     pred_attributes = torch.where(y, torch.tensor(1), torch.tensor(0))
#
#     # # pred_attribute = F.softmax(pred_attribute, dim=1)
#     # topk, topkindex = torch.topk(pred_attribute, k=180, dim=1)
#     # # print(topkindex)
#     # y = torch.zeros(imgs.shape[0], att.shape[1])
#     # # topk = topk.to(torch.int64)
#     # pred_attributes = y.scatter(dim=1, index=topkindex, value=1)
#     train_seen_attributes = torch.cat((train_seen_attributes, pred_attributes), dim=0).int()  # 2967*312
# print("train_seen_attributes:\n", train_seen_attributes)
# torch.save(train_seen_attributes, "../pred_attribute/CUB50_train_seen_attribute9_4.pth")

# 测试集中的可见类属性预测

test_seen_image = CustomedDataset(test_seen_img_files, data_transforms)
data1 = torch.utils.data.DataLoader(test_seen_image, batch_size=64, shuffle=False, num_workers=0)
# 预测属性
test_seen_attributes = torch.empty(0).to(device)
for i_batch, imgs in enumerate(data1):  # 遍历训练数据集
    print("第{}批".format(i_batch))
    imgs = imgs.to(device)
    pred_attribute = attribute_model(imgs)  # 64*312
    pred_attribute = torch.sigmoid(pred_attribute)

    y = torch.gt(pred_attribute, 0.45)
    pred_attributes = torch.where(y, torch.tensor(1), torch.tensor(0))
    test_seen_attributes = torch.cat((test_seen_attributes, pred_attributes), dim=0).int()  # 2967*312
print("test_seen_attributes:\n", test_seen_attributes)
print(test_seen_attributes.shape)
torch.save(test_seen_attributes, "../pred_attribute/CUB_test_seen_attribute9_5.pth")  # 实质上是CUB50



test_unseen_image = CustomedDataset(test_unseen_img_files, data_transforms)
data2 = torch.utils.data.DataLoader(test_unseen_image, batch_size=64, shuffle=False, num_workers=0)
# 预测属性
test_unseen_attributes = torch.empty(0).to(device)
for i_batch, imgs in enumerate(data2):  # 遍历训练数据集
    print("第{}批".format(i_batch))
    imgs = imgs.to(device)
    pred_attribute = attribute_model(imgs)  # 64*312
    pred_attribute = torch.sigmoid(pred_attribute)

    y = torch.gt(pred_attribute, 0.45)
    print(torch.sum(y,dim=1))
    pred_attributes = torch.where(y, torch.tensor(1), torch.tensor(0))

    test_unseen_attributes = torch.cat((test_unseen_attributes, pred_attributes), dim=0).int()  # 2967*312
print("unseen_attributes:\n", test_unseen_attributes)
print(test_unseen_attributes.shape)
torch.save(test_unseen_attributes, "../pred_attribute/CUB50_test_unseen_attribute9_5.pth")