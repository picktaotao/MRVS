import torch
from core.CUB50_DataLoader import CUB50DataLoader
# from new_image.CUB_newload import CUBDataLoader
from global_setting import NFS_path
from core.DAZLE_CUB_score import DAZLE
from core.sample_encoder import Encoder
import time
import numpy as np


# idx_GPU = 0
# device = torch.device("cuda:{}".format(idx_GPU) if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")
torch.backends.cudnn.benchmark = True


dataloader = CUB50DataLoader(NFS_path,device,is_balance=True)

batch_size = 100
niters = (dataloader.ntrain)*20//batch_size  # 7057*2//160 = 88
# niters=50
dim_f = 2048  # 特征维度
dim_v = 300  # 属性词向量的维度
init_w2v_att = dataloader.w2v_att
att = dataloader.att
# att[att<=0.05]=0
att[att>0]=1

# normalize_att = dataloader.normalize_att
lambda_ = 0.1  # 0.1
seenclass = dataloader.seenclasses
print("可见类unique类标签:\n",seenclass)
unseenclass = dataloader.unseenclasses
uniform_att_1 = False
uniform_att_2 = True
trainable_w2v = False

model = DAZLE(dim_f,dim_v,init_w2v_att,att,None,
            seenclass,unseenclass,
            lambda_,trainable_w2v,normalize_V=True,normalize_F=True,is_conservative=True,
            uniform_att_1=uniform_att_1,uniform_att_2=uniform_att_2,
            prob_prune=0,desired_mass=1, is_conv=False,
            is_bias=True)
model.load_state_dict(torch.load('CUB50_main_model_weights/CUB50_main_model_weights_all_10_8_2000b_40e_23.pth'))
# model.load_state_dict(torch.load('../new_image/CUB_add_model_weights7_15.pth'))
model.eval() # set the model to evaluation mode
model.to(device)
print("*"*30)
print("seenclass prototypes generation")
print("generating prototypes")
# all_train_seen_visual_features=torch.load('../Encoder_train_prototypes/all_train_seen_visual_features.pth')

# encoder = Encoder(input_dim=dim_f, hidden_dim=dim_f//2, output_dim=dim_f)
# encoder.load_state_dict(torch.load('CUB_sample_encoder_model7_24.pth'))
# encoder.eval()
# encoder.to(device)


# def get_seenclass_prototype(feature,label):
#     # device = torch.device("cuda:{}".format(0) if torch.cuda.is_available() else "cpu")
#     device = torch.device("cpu")
#     unique_label = torch.unique(label)
#     prototypes = torch.empty(0).to(device)
#     for i in unique_label:
#         label_index = torch.nonzero(label == i)  # 对应的样本索引
#         image_features = feature[label_index]
#         prototype_feature = torch.mean(image_features, dim=0)
#         prototypes = torch.cat((prototypes, prototype_feature), dim=0)
#     return prototypes  # 二维张量，batch中的类别数*对应的2048维的类视觉原型
#
# for i in range(0, niters):
#     print("第{}次循环".format(i))
#     batch_label, batch_feature,batch_att,batch_class_att = dataloader.next_batch6(batch_size,all_train_seen_visual_features)
#
#
#
#
#     batch_prototypes = get_seenclass_prototype(batch_feature,batch_label) # 40个类原型
#     print(batch_prototypes.shape)
#     batch_prototypes = batch_prototypes.to(device)
#     if i == 0:
#         allbatch_seenclass_prototypes = batch_prototypes
#     else:
#         allbatch_seenclass_prototypes += batch_prototypes
# all_seenclass_prototypes = allbatch_seenclass_prototypes/niters
# print("all_seenclass_prototypes shape:", all_seenclass_prototypes.shape)
# torch.save(all_seenclass_prototypes, "../Encoder_train_prototypes/CUB_all_seenclass_prototypes_7_19.pth")

# for i in range(0, niters):
#     print("第{}次循环".format(i))
#     batch_label, batch_feature,batch_att,batch_class_att = dataloader.next_batch(batch_size)
#
#
#     # 与seenclass对应的原型
#     outpackage = model(batch_feature,batch_class_att)
#     inpackage = outpackage
#     inpackage['batch_label'] = batch_label
#
#     batch_prototypes = model.get_seenclass_prototype(inpackage) # 40个类原型
#     batch_prototypes = batch_prototypes.to(device)
#     if i == 0:
#         allbatch_seenclass_prototypes = batch_prototypes
#     else:
#         allbatch_seenclass_prototypes += batch_prototypes
# all_seenclass_prototypes = allbatch_seenclass_prototypes/niters
# print("all_seenclass_prototypes shape:", all_seenclass_prototypes.shape)
# torch.save(all_seenclass_prototypes, "CUB_all_seenclass_prototypes_7_13.pth")

# pred_prototypes = torch.load('CUB_all_seenclass_prototypes_30epoch_trueatt.pth')
# pred_prototypes=torch.load('CUB_all_seenclass_prototypes7_26.pth')
# '''可见类原型修正，效果不好'''
# seen_feature = dataloader.data['train_seen']['resnet_features'].to(device)  # 样本特征
# seen_label = dataloader.data['train_seen']['labels']  # 不可见类样本标签
# # seen_attribute = torch.load("../pred_attribute/CUB_train_seen_attribute.pth")
# seen_attribute=att[seen_label]
# output = model(seen_feature,seen_attribute)
# image_features = output['F_att_v']
#
# # 计算样本特征与不可见类原型之间的相似性
# dot = torch.matmul(image_features, pred_prototypes.t())
# # 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
# norm_a = torch.norm(image_features, dim=1, keepdim=True)
# norm_b = torch.norm(pred_prototypes, dim=1, keepdim=True)
# # 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
# sample_prototypes_sim = dot / (norm_a * norm_b.t())
# max_values, max_indices = torch.topk(sample_prototypes_sim, k=30, dim=0)
# print(max_indices.shape)
# max_indices_T=max_indices.T
# new_pred_prototypes = torch.empty(0)  # 存放一个不可见类所具有全部属性的视觉特征
#
# for i in range(seenclass.size(0)):
#     everyclasssample=image_features[max_indices_T[i]]
#     print(max_indices_T[i].shape[0])
#     everyclasssamplefeaturesum=torch.zeros((dim_f))
#     a = 0
#     for j in range(max_indices_T[i].shape[0]):
#         print(max_indices_T[i][j])
#         print(everyclasssample[j].shape)
#         everyclasssamplefeaturesum+=pred_prototypes[i]
#         if seen_label[max_indices_T[i][j]]==seenclass[i]:
#             print(j)
#             a+=1
#             everyclasssamplefeaturesum+=everyclasssample[j]
#     everyclasssamplefeaturesum=torch.reshape(everyclasssamplefeaturesum,(1,-1))
#
#     # everyclasssamplefeaturesum=torch.sum(everyclasssample,dim=0)
#     # everyclasssamplefeaturesum=torch.reshape(everyclasssamplefeaturesum,(1,-1))
#     print(everyclasssamplefeaturesum.shape)
#     # print(pred_prototypes[i].shape)
#     everynewprototype=everyclasssamplefeaturesum/(1+a)
#
#     # newfeaturesum=everyclasssamplefeaturesum+pred_prototypes[i]
#     # newfeaturesum=torch.reshape(newfeaturesum,(1,-1))
#     # everynewprototype=newfeaturesum/(1+everyclasssamplefeaturesum.shape[0])
#     new_pred_prototypes=torch.cat((new_pred_prototypes,everynewprototype),dim=0)
#     print(pred_prototypes[i].shape)
# print("pred_prototypes.shape: ",pred_prototypes.shape)
# torch.save(new_pred_prototypes,"CUB_all_seenclass_prototypes7_26_new.pth")


'''now'''
seen_feature = dataloader.data['train_seen']['resnet_features'].to(device)  # 样本特征
seen_label = dataloader.data['train_seen']['labels']  # 不可见类样本标签
print("可见类的label:",seen_label)
# seen_attribute = torch.load("../pred_attribute/CUB_train_seen_attribute.pth")
seen_attribute=att[seen_label]
output = model(seen_feature,seen_attribute)
image_features = output['F_att_v']
sum=0
seen_pred_prototypes = torch.empty(0)
for i in range(seenclass.size(0)):
    print(seenclass[i])
    everyclassindex=torch.where(seen_label==seenclass[i])[0]
    num=everyclassindex.shape[0]
    everyclassfeature=image_features[everyclassindex]
    everyclassfeaturesum=torch.sum(everyclassfeature,dim=0)
    everyclassfeaturesum=torch.reshape(everyclassfeaturesum,(1,-1))
    everynewprototype=everyclassfeaturesum/num
    seen_pred_prototypes=torch.cat((seen_pred_prototypes,everynewprototype),dim=0)
    print(everyclassfeaturesum.shape)
    print(seen_pred_prototypes.shape)
    print(num)
    sum+=num
print(sum)
    # everyclasssamplefeaturesum=torch.sum(everyclasssample,dim=0)
    # everyclasssamplefeaturesum=torch.reshape(everyclasssamplefeaturesum,(1,-1))

print("pred_prototypes.shape: ",seen_pred_prototypes.shape)
torch.save(seen_pred_prototypes,"CUB50_all_seenclass_prototypes10_8.pth")
#


'''利用测试修正'''
# test_seen_feature = dataloader.data['test_seen']['resnet_features'].to(device)  # 样本特征
# test_seen_label = dataloader.data['test_seen']['labels']  # 不可见类样本标签
# test_seen_attribute = torch.load("../pred_attribute/CUB_test_seen_attribute7_26.pth")
#
# pred_prototypes=torch.load("CUB_all_seenclass_prototypes7_26_new.pth")
# print(pred_prototypes.shape)
#
# output = model(test_seen_feature,test_seen_attribute)
# image_features = output['F_att_v']
#
# # 计算样本特征与不可见类原型之间的相似性
# dot = torch.matmul(image_features, pred_prototypes.t())
# # 计算两个张量每一行的范数，得到一个1000x1和一个40x1的向量
# norm_a = torch.norm(image_features, dim=1, keepdim=True)
# norm_b = torch.norm(pred_prototypes, dim=1, keepdim=True)
# # 用点积除以范数的乘积，得到一个1000x40的矩阵，表示余弦相似度
# sample_prototypes_sim = dot / (norm_a * norm_b.t())
# max_values, max_indices = torch.topk(sample_prototypes_sim, k=1, dim=0)
# print("max_values:\n",max_values)
# print(max_indices.shape)
# max_indices_T=max_indices.T
# new_pred_prototypes = torch.empty(0)  # 存放一个不可见类所具有全部属性的视觉特征
#
# for i in range(seenclass.size(0)):
#     everyclasssample=image_features[max_indices_T[i]]
#     everyclasssamplefeaturesum=torch.sum(everyclasssample,dim=0)
#     # everyclasssamplefeaturesum=torch.reshape(everyclasssamplefeaturesum,(1,-1))
#     print(everyclasssamplefeaturesum.shape)
#     print(pred_prototypes[i].shape)
#     newfeaturesum = everyclasssamplefeaturesum+pred_prototypes[i]
#     newfeaturesum = torch.reshape(newfeaturesum,(1,-1))
#     everynewprototype = newfeaturesum/(1+everyclasssamplefeaturesum.shape[0])
#     new_pred_prototypes = torch.cat((new_pred_prototypes,everynewprototype),dim=0)
#     print(pred_prototypes[i].shape)
# print("new_pred_prototypes.shape: ",new_pred_prototypes.shape)
# torch.save(new_pred_prototypes,"CUB_all_seenclass_prototypes7_26_new.pth")

''' 分多次生成可见类原型 '''
# partbatch_seenclass_prototypes = torch.empty(0).to(device)
#
# m=0
# print(m)
# partseenclass = seenclass[m*50:(m+1)*50]
# # partseenclass=seenclass[j*50:]
# for i in range(0, 80):
#
#     print("第{}次循环".format(i))
#     batch_label, batch_feature, batch_att, batch_class_att = dataloader.next_batch4(batch_size,partseenclass)
#
#     # 与seenclass对应的原型
#     outpackage = model(batch_feature, batch_class_att)
#     inpackage = outpackage
#     inpackage['batch_label'] = batch_label
#     # feat_encoder = encoder(outpackage['F_att_v'])
#     #
#     # inpackage['F_att_v'] = feat_encoder
#
#     batch_prototypes = model.get_seenclass_prototype(inpackage) # 40个类原型
#     batch_prototypes = batch_prototypes.to(device)
#     if i == 0:
#         partbatch_seenclass_prototypes = batch_prototypes
#     else:
#         partbatch_seenclass_prototypes += batch_prototypes
# part_seenclass_prototypes = partbatch_seenclass_prototypes/80
# print(part_seenclass_prototypes.shape)
# print(m)
#
# save_path = "./CUB_seen_prototypes/CUB_part_seenclass_prototypes_"+str(m)+"_7_26.pth"
# torch.save(part_seenclass_prototypes, save_path)
# all_seenclass_prototypes = torch.empty(0).to(device)
# for j in range(3):
#     part_prototypes = torch.load("./CUB_seen_prototypes/CUB_part_seenclass_prototypes_"+str(j)+"_7_26.pth")
#     print(part_prototypes)
#     all_seenclass_prototypes = torch.cat((all_seenclass_prototypes,part_prototypes),dim=0)
# print(all_seenclass_prototypes.shape)
# torch.save(all_seenclass_prototypes, "CUB_all_seenclass_prototypes7_26.pth")

# 分开抽样
# allbatch_seenclass_prototypes = torch.empty(0).to(device)
# partbatch_seenclass_prototypes = torch.empty(0).to(device)
# for j in range(4):
#     if j<3:
#         partseenclass=seenclass[j*40:(j+1)*40]
#     else:
#         partseenclass=seenclass[j*40:]
#
#     for i in range(0, niters):
#         print("第{}次循环".format(i))
#         batch_label, batch_feature, batch_att, batch_class_att = dataloader.next_batch4(batch_size,partseenclass)
#
#         samples_seenclass_att = dataloader.att[batch_label].to(device)
#         samples_seenclass_att[samples_seenclass_att<=0] = 0
#         samples_seenclass_att[samples_seenclass_att>0] = 1
#
#         # 与seenclass对应的原型
#         outpackage = model(batch_feature,samples_seenclass_att)
#         inpackage = outpackage
#         inpackage['batch_label'] = batch_label
#         # device1 = torch.device("cuda:{}".format(0) if torch.cuda.is_available() else "cpu")
#         # inpackage = inpackage.to(device1)
#         batch_prototypes = model.get_seenclass_prototype(inpackage) # 40个类原型
#         batch_prototypes = batch_prototypes.to(device)
#         if i == 0:
#             partbatch_seenclass_prototypes = batch_prototypes
#         else:
#             partbatch_seenclass_prototypes += batch_prototypes
#     part_seenclass_prototypes = partbatch_seenclass_prototypes/niters
#     if j==0:
#         allbatch_seenclass_prototypes=part_seenclass_prototypes
#     else:
#         allbatch_seenclass_prototypes=torch.cat((allbatch_seenclass_prototypes,part_seenclass_prototypes),dim = 0)
# print("all_seenclass_prototypes shape:", allbatch_seenclass_prototypes.shape)
# torch.save(allbatch_seenclass_prototypes, "CUB_all_seenclass_prototypes.pth")






