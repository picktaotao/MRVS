import os,sys
#import scipy.io as sio
import torch
import numpy as np
import h5py
import time
import pickle
import pdb
from sklearn import preprocessing
from global_setting import NFS_path
from core.data_split import data_split

img_dir = os.path.join(NFS_path,'data/CUB/')
mat_path = os.path.join(NFS_path,'data/xlsa17/data/CUB/res101.mat')

class CUB50DataLoader():
    def __init__(self, data_path, device, is_scale=False, is_balance=True):

        print(data_path)
        sys.path.append(data_path)

        self.data_path = data_path
        self.device = device
        self.dataset = 'CUB'
        print('$'*30)
        print(self.dataset)
        print('$'*30)
        self.datadir = self.data_path + 'data/{}/'.format(self.dataset)
        self.index_in_epoch = 0
        self.epochs_completed = 0
        self.is_scale = is_scale
        self.is_balance = is_balance
        if self.is_balance:
            print('Balance dataloader')
        self.read_matdataset()
        self.get_idx_classes()

    def next_batch(self, batch_size):
        if self.is_balance:
            idx = []
            n_samples_class = max(batch_size // self.ntrain_class, 1)
            sampled_idx_c = np.random.choice(np.arange(self.ntrain_class), min(self.ntrain_class, batch_size),
                                             replace=False).tolist()
            for i_c in sampled_idx_c:
                idxs = self.idxs_list[i_c]
                idx.append(np.random.choice(idxs, n_samples_class))
            idx = np.concatenate(idx)
            idx = torch.from_numpy(idx)
        else:
            idx = torch.randperm(self.ntrain)[0:batch_size]

        batch_feature = self.data['train_seen']['resnet_features'][idx].to(self.device)
        batch_label = self.data['train_seen']['labels'][idx].to(self.device)
        batch_att = self.att[batch_label].to(self.device)
        batch_class_att = batch_att
        # batch_class_att[batch_class_att <= 0.01] = 0
        batch_class_att[batch_class_att > 0] = 1
        return batch_label, batch_feature, batch_att, batch_class_att


    def next_batch1(self, test_att, test_batch_size, start_index):  # test_batch_size = 2000
        if start_index < self.ntest:
            end_index = min(start_index + test_batch_size, self.ntest)
            batch_feature = self.data['test_unseen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['test_unseen']['labels'][start_index:end_index].to(self.device)
            batch_att = test_att[start_index:end_index].to(self.device)
        return batch_feature, batch_label, batch_att, end_index

    def next_batch5(self, train_batch_size, start_index):  # test_batch_size = 2000
        if start_index < self.ntrain:
            end_index = min(start_index + train_batch_size, self.ntrain)
            batch_feature = self.data['train_seen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['train_seen']['labels'][start_index:end_index].to(self.device)
            # batch_att = self.att[batch_label].to(self.device)
            batch_att = self.att[batch_label].to(self.device)
            batch_class_att = batch_att
            batch_class_att[batch_class_att <= 0] = 0
            batch_class_att[batch_class_att > 0] = 1
        return batch_feature, batch_label, batch_att, batch_class_att,end_index

    def next_batch3(self, train_batch_size, start_index,pred_att):
        if start_index < self.ntrain:
            end_index = min(start_index + train_batch_size, self.ntrain)
            batch_feature = self.data['train_seen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['train_seen']['labels'][start_index:end_index].to(self.device)
            att = pred_att[start_index:end_index]
            # att = self.att[batch_label.long()].to(self.device)

        return batch_feature, batch_label, end_index, att

    def next_batch4(self, test_batch_size, start_index,pred_att):
        if start_index < self.ntest_seen:
            end_index = min(start_index + test_batch_size, self.ntest_seen)
            batch_feature = self.data['test_seen']['resnet_features'][start_index:end_index].to(self.device)
            batch_label = self.data['test_seen']['labels'][start_index:end_index].to(self.device)
            att=pred_att[start_index:end_index]
        return batch_feature, batch_label, end_index,att


    def get_idx_classes(self):
        n_classes = self.seenclasses.size(0)
        self.idxs_list = []
        train_label = self.data['train_seen']['labels']
        for i in range(n_classes):
            idx_c = torch.nonzero(train_label == self.seenclasses[i].cpu()).cpu().numpy()
            idx_c = np.squeeze(idx_c)
            self.idxs_list.append(idx_c)
        return self.idxs_list

    def read_matdataset(self):

        path = self.datadir + 'feature_map_ResNet_101_{}50.hdf5'.format(self.dataset)
        print('_____')
        print(path)
        tic = time.clock()
        hf = h5py.File(path, 'r')
        features = np.array(hf.get('feature_map'))
        labels = np.array(hf.get('labels'))
        # trainval_loc = np.arange(0,2338)  # 2338个可见类
        # test_unseen_loc = np.arange(2338,2936)  # 598个不可见类
        train_seen,test_seen = data_split()
        trainval_loc=train_seen  # 1938
        test_seen_loc=test_seen  # 400
        test_unseen_loc=np.arange(2338,2936)  # 598
        print('Expert Attribute')
        att = np.array(hf.get('att'))
        self.att = torch.from_numpy(att).float().to(self.device)

        w2v_att = np.array(hf.get('w2v_att'))
        self.w2v_att = torch.from_numpy(w2v_att).float().to(self.device)

        print('Finish loading data in ', time.clock() - tic)

        train_feature = features[trainval_loc]
        test_seen_feature = features[test_seen_loc]
        test_unseen_feature = features[test_unseen_loc]
        if self.is_scale:
            scaler = preprocessing.MinMaxScaler()
            train_feature = scaler.fit_transform(train_feature)
            test_unseen_feature = scaler.fit_transform(test_unseen_feature)

        train_feature = torch.from_numpy(train_feature).float()  # .to(self.device)
        test_unseen_feature = torch.from_numpy(test_unseen_feature)  # .float().to(self.device)
        test_seen_feature = torch.from_numpy(test_seen_feature)

        train_label = torch.from_numpy(labels[trainval_loc]).long()  # .to(self.device)
        test_seen_label = torch.from_numpy(labels[test_seen_loc]).long()
        test_unseen_label = torch.from_numpy(labels[test_unseen_loc])  # .long().to(self.device)

        self.seenclasses = torch.from_numpy(np.unique(train_label.cpu().numpy())).to(self.device)
        self.unseenclasses = torch.from_numpy(np.unique(test_unseen_label.cpu().numpy())).to(self.device)
        self.ntrain = train_feature.size()[0]
        self.ntest = test_unseen_feature.size()[0]  # 测试不可见类样本数量
        self.ntest_seen = test_seen_feature.size()[0]
        self.ntrain_class = self.seenclasses.size(0)
        self.ntest_class = self.unseenclasses.size(0)
        self.train_class = self.seenclasses.clone()
        self.allclasses = torch.arange(0, self.ntrain_class + self.ntest_class).long()
        self.totalclassnum = self.ntrain_class + self.ntest_class

        #        self.train_mapped_label = map_label(train_label, self.seenclasses)

        self.data = {}
        self.data['train_seen'] = {}
        self.data['train_seen']['resnet_features'] = train_feature
        self.data['train_seen']['labels'] = train_label

        self.data['train_unseen'] = {}
        self.data['train_unseen']['resnet_features'] = None
        self.data['train_unseen']['labels'] = None

        self.data['test_seen'] = {}
        self.data['test_seen']['resnet_features'] = test_seen_feature
        self.data['test_seen']['labels'] = test_seen_label

        self.data['test_unseen'] = {}
        self.data['test_unseen']['resnet_features'] = test_unseen_feature
        self.data['test_unseen']['labels'] = test_unseen_label